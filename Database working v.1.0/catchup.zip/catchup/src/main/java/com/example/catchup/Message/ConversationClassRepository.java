package com.example.catchup.Message;
import com.example.catchup.User.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
public interface ConversationClassRepository  extends JpaRepository<ConversationClass,Long> {
    @Modifying
    @Query("update ConversationClass cc set cc.option = :option where cc.id = :id")
    void updateConversationClass(@Param("option") String option,@Param("id") Long id);

    @Query("select count (id) from ConversationClass")
    int getTotalConversationClassNum();

    @Modifying
    @Query("delete from ConversationClass cc where cc.id = :id")
    void deleteConversationClass(@Param("id") Long id);
}
