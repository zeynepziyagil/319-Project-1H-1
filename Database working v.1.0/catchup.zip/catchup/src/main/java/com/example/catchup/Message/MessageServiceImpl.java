package com.example.catchup.Message;

public class MessageServiceImpl {
}
