package com.example.catchup.Assignment;

public class ArtifactServiceImpl {
}
