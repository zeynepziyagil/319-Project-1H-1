package com.example.catchup.Message;
import com.example.catchup.User.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
public interface PairRepository  extends JpaRepository< Pair,Long>{

    @Query("select count (id) from Pair")
    int getTotalPairNum();

    @Modifying
    @Query("delete from Pair p where p.id = :id")
    void deletePair(@Param("id") Long id);

}

