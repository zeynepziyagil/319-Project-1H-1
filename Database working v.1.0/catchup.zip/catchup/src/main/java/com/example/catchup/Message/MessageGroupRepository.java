package com.example.catchup.Message;

public interface MessageGroupRepository {
}
