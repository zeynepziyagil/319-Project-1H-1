package com.example.catchup.User;
import java.util.List;
import java.util.Optional;
public interface TimeTableService {
    List<TimeTable> findAll();

    Optional<TimeTable> findById(Long id);

    void save(TimeTable timeTable);

    void delete(Long id);

    void updateTimeTable( String timeTable[][], Long id);
}
