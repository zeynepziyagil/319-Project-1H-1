package com.example.catchup.Review;

import com.example.catchup.User.Student;

import java.util.List;
import java.util.Optional;

public interface PeerReviewService
{
    List<PeerReview> findAll();

    Optional<PeerReview> findById(Long id);

    void save(PeerReview peerReview);

    void delete(Long id);

    void updatePeerReview(String name, List<String> feedback, double grade, int questionNum, Student rater, Student reciever);

    List<String> getQuestions(Long id);

    List<String> getFeedback(Long id);

    double getGrade(Long id);

    int getTotalPeerReviewNum();
}
