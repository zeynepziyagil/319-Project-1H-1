package com.example.catchup.User;
import com.example.catchup.Course.Course;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Review.PeerReview;
import com.vladmihalcea.hibernate.type.array.ListArrayType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@PrimaryKeyJoinColumn(name = "user_id")
@TypeDef(
        name = "list-array",
        typeClass = ListArrayType.class
)
public class Student extends User{

    @Column(unique=true)
    private long studentId;
    //other properties
    int currentSemester;
    String department;
    double averagePeerGrade;

    @ManyToOne
    @JoinColumn(name = "group_id")
    private ProjectGroup group;


    @OneToMany(mappedBy = "student",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    private List<PeerReview> reviews;

    //CALENDAR?

    public Student() {
    }

    public Student(String name, String surname, String mail, String password, long studentId, int currentSemester, String department) {
        super(name,surname,mail,password,"student");
        this.studentId = studentId;
        this.currentSemester = currentSemester;
        this.department = department;
        this.averagePeerGrade = 0;
        reviews = new ArrayList<>(0);
    }

    public long getStudentId() {
        return studentId;
    }

    public int getCurrentSemester() {
        return currentSemester;
    }

    public String getDepartment() {
        return department;
    }

    public double getAveragePeerGrade() {
        return averagePeerGrade;
    }

    public ProjectGroup getGroups() {
        return group;
    }

    public List<PeerReview> getReviews() {
        return reviews;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", currentSemester=" + currentSemester +
                ", department='" + department + '\'' +
                ", averagePeerGrade=" + averagePeerGrade +
                ", groups=" + group +
                ", reviews=" + reviews +
                '}';
    }
}
