package com.example.catchup;

import com.example.catchup.Course.Course;
import com.example.catchup.Course.CourseService;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.InstructorService;
import com.example.catchup.User.StudentService;
import com.example.catchup.User.TeachingAssistantService;
import com.example.catchup.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Long.parseLong;

@RestController
@RequestMapping()
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@CrossOrigin("*")
public class DashboardController {
    private final StudentService studentService;
    private final InstructorService instructorService;
    private final TeachingAssistantService teachingService;
    private final UserService userService;
    private final CourseService courseService;
    private final ProjectGroupService projectGroupService;

    @Autowired
    public DashboardController(StudentService studentService, InstructorService instructorService, TeachingAssistantService teachingService, UserService userService, CourseService courseService, ProjectGroupService projectGroupService) {
        this.studentService = studentService;
        this.instructorService = instructorService;
        this.teachingService = teachingService;
        this.userService = userService;
        this.courseService = courseService;
        this.projectGroupService = projectGroupService;
    }

    @GetMapping(path = "/dashboard/{id}")
    public Course getCoursesDashboard(@PathVariable("id") Long id){ //???? LONG????//Not give any error in java
        System.out.println("neden allahım");
        return userService.getCourseById(id);
    }

    @GetMapping("/dashboard/{id}/1")//bak duruma göre
    public ProjectGroup getGroupsDashboard(@PathVariable("id") Long id){
       //check if the id belongs student or not
        if(userService.getRoleById(id).equals("student"))
        {
            return studentService.getGroupsById(id);
        }
        return null;
    }

}
