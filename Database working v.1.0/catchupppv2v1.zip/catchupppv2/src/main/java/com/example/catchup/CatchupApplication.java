package com.example.catchup;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Assignment.AssignmentRepository;
import com.example.catchup.Course.*;
import com.example.catchup.Group.Advertisement;
import com.example.catchup.Group.AdvertisementRepository;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupRepository;
import com.example.catchup.User.*;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


@Configuration
@EnableJpaRepositories(basePackages = {
        "com.example.catchup.Course", "com.example.catchup.Group", "com.example.catchup.User", "com.example.catchup.Assignment",
        "com.example.catchup.Review"
})
@SpringBootApplication
public class CatchupApplication {

    public static void main(String[] args) {
        SpringApplication.run(CatchupApplication.class, args);
    }

    @Bean
    ApplicationRunner applicationRunner(CourseRepository Repository){
        return args -> {


           /* Course course = new Course("CS224");

            //Student user = new Student("Zeynep","Kaş","il.com","test123",2149, 5,"CS");
            TeachingAssistant user1 = new TeachingAssistant("Elgun", "Kuzen", "elguil.com", "test12");
           // Instructor user2 = new Instructor("Eray", "Tüzün", "etuil.com","test123");
            List<User> us = course.getUsers();
            course.getUsers().add(user1);
            course.setUsers(course.getUsers());
            //course.getUsers().add(user2);
            //course.setUsers(course.getUsers());
           Repository.save(course);*/
        };
    }
}