package com.example.catchup.User;

public class DoubleRequest {
    private double average;

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }
}
