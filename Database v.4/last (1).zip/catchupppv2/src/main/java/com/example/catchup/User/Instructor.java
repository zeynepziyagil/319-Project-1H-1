package com.example.catchup.User;
import com.vladmihalcea.hibernate.type.array.ListArrayType;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;

@Entity
@PrimaryKeyJoinColumn(name = "user_id")
@TypeDef(
        name = "list-array",
        typeClass = ListArrayType.class
)
public class Instructor extends User{
    //properties
    private String officeLocation;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "timeTableId", referencedColumnName = "id")
    private TimeTable timeTable;

    public Instructor() {
        this.officeLocation = "";
        TimeTable timeTable = new TimeTable();
    }

    public Instructor(String name, String surname, String mail, String password) {
        super(name, surname, mail, password, "instructor");
        //this.timeTable = timeTable;
        TimeTable timeTable = new TimeTable();
    }

    public String getOfficeLocation() {
        return officeLocation;
    }

    public TimeTable getTimeTable() {
        return timeTable;
    }

    @Override
    public String toString() {
        return "Instructor{" +
                "officeLocation='" + officeLocation + '\'' +
                ", timeTable=" + timeTable +
                '}';
    }
}
