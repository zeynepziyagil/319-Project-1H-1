package com.example.catchup.File;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Review.ArtifactReview;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

@Service
public class DocServiceImpl implements DocService {

    //properties
    private DocRepository docRepository;

    @Autowired
    public void setDocRepository(DocRepository docRepository) {
        this.docRepository = docRepository;
    }

    @Override
    public Doc saveFile(MultipartFile file) {
        String docName = file.getOriginalFilename();
        try{
            Doc doc = new Doc(docName,file.getContentType(), file.getBytes());
            return docRepository.save(doc);
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void updateGroup(ProjectGroup group, Integer id) {
        docRepository.updateGroup(group,id);
    }

    @Override
    public void saveDoc(Doc doc) {
        docRepository.save(doc);
    }

    @Override
    public Optional<Doc> getFile(Integer id) {
        return docRepository.findById(id);
    }

    @Override
    public List<Doc> getFiles() {
        return docRepository.findAll();
    }

    @Override
    public void updateAssignment(Assignment assignment, Integer id) {
        docRepository.updateAssignment(assignment,id);
    }

    @Override
    public Integer getDocByIds(Long assignment_id, Long group_id) {
        return docRepository.getDocByIds(assignment_id,group_id);
    }

    @Override
    public Optional<Doc> findById(Integer id) {
        return docRepository.findById(id);
    }

    @Override
    public void updateReviews(List<ArtifactReview> reviews, Integer id) {
        docRepository.updateReviews(reviews, id);
    }
}
