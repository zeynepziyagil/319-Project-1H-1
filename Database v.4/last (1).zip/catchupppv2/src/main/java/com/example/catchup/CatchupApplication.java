package com.example.catchup;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Assignment.AssignmentRepository;
import com.example.catchup.Course.*;
import com.example.catchup.Group.Advertisement;
import com.example.catchup.Group.AdvertisementRepository;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupRepository;
import com.example.catchup.User.*;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@EnableJpaRepositories(basePackages = {
        "com.example.catchup.Course", "com.example.catchup.Group", "com.example.catchup.User", "com.example.catchup.Assignment",
        "com.example.catchup.Review","com.example.catchup.File"
})
@SpringBootApplication
public class CatchupApplication {

    public static void main(String[] args) {
        SpringApplication.run(CatchupApplication.class, args);
    }

    @Bean
    ApplicationRunner applicationRunner(AssignmentRepository Repository){
        return args -> {

/*
            Course course = new Course("CS319");

            Student user = new Student("İlke","Kaş","heyo@","pass",868, 5,"CS");
            Student user2 = new Student("İlke2","Kaş2","heyo2@","pass",8168, 5,"CS");
            Student user3 = new Student("İlke3","Kaş3","heyo3@","pass",8268, 5,"CS");
            //Instructor user3 = new Instructor("İlke3","Kaş3","heyo3@","pass",8268, 5,"CS");
            ProjectGroup group = new ProjectGroup("1h",6,3);
            TeachingAssistant user5 = new TeachingAssistant("Elgun", "Kuzen", "elguil.com", "test12");
            Instructor user4 = new Instructor("Selim", "Aksoy", "uğur@","test123");
            List<Student> us = group.getStudents();
            us.add(user);
            us.add(user2);
            us.add(user3);
            group.setStudents(us);
            user.setGroups(group);
            List<ProjectGroup> g = course.getGroups();
            g.add(group);
            course.setGroups(g);
            group.setCourse(course);


            user.setCourse(course);
            course.getUsers().add(user);
            course.getUsers().add(user2);
            course.getUsers().add(user3);
            course.getUsers().add(user4);
            course.getUsers().add(user5);
            course.setUsers(course.getUsers());
            Repository.save(course);
*/
          //  Course course = new Course("pe67");
           // Repository.save(course); */
            //System.out.println(course.getCode());
/*
            Student user = new Student("Aysu","Aydın","aysu@","pass",78, 5,"CS");
            ProjectGroup group = new ProjectGroup("1G",4);
            List<Student> students = group.getStudents();
            students.add(user);
            Course course = new Course("METE102");
            user.setCourse(course);
            List<ProjectGroup> groups = course.getGroups();
            groups.add(group);
            course.setGroups(groups);
            Announcement ann = new Announcement("Announcement title1","description3");
            Announcement ann2 = new Announcement("Announcement title2","description4");
            ann.setCourse(course);
            ann2.setCourse(course);
            List<Announcement> annList = course.getAnnouncements();
            annList.add(ann);
            annList.add(ann2);
            course.setAnnouncements(annList);

            Advertisement ads = new Advertisement("ADVERTISEMENT TİTLE2","ADVERTISEMENT DESCRIPTION 2");
            ads.setCourse(course);
            List<Advertisement> adList = course.getAds();
            adList.add(ads);
            course.setAds(adList);

            Repository.save(course);
*/
        };


    }
}