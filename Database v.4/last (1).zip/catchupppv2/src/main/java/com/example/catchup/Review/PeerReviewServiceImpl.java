package com.example.catchup.Review;

import com.example.catchup.User.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service

public class PeerReviewServiceImpl implements PeerReviewService{

    private PeerReviewRepository peerReviewRepository;
    @Autowired
    public void setAssignmentRepository(PeerReviewRepository peerReviewRepository) {
        this.peerReviewRepository = peerReviewRepository;
    }

    @Override
    public List<PeerReview> findAll() {
        return peerReviewRepository.findAll();
    }

    @Override
    public Optional<PeerReview> findById(Long id) {
        return peerReviewRepository.findById(id);
    }

    @Override
    public void save(PeerReview peerReview) {
        peerReviewRepository.save(peerReview);
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long id){
        peerReviewRepository.deletePReview(id);
    }


    @Override
    public int getTotalPeerReviewNum() {
        return peerReviewRepository.getTotalPReviewNum();
    }


    @Override
    public String getFeedback(Long id) {
        return peerReviewRepository.getFeedback(id);
    }

    @Override
    public List<Double> getGrade(Long id) {
        return peerReviewRepository.getGrade(id);
    }

    @Override
    public List<String> getGivenFeedbacks(Student rater) {
        return peerReviewRepository.getGivenFeedbacks(rater);
    }
}