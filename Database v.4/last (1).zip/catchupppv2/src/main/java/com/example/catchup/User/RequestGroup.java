package com.example.catchup.User;

import java.util.List;

public class RequestGroup {
    private String name;
    private int memberNum;
    private int maxMemberNum;
    private String studentId1;
    private String studentId2;
    private String studentId3;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMemberNum() {
        return memberNum;
    }

    public void setMemberNum(int memberNum) {
        this.memberNum = memberNum;
    }

    public int getMaxMemberNum() {
        return maxMemberNum;
    }

    public void setMaxMemberNum(int maxMemberNum) {
        this.maxMemberNum = maxMemberNum;
    }

    public String getStudentId1() {
        return studentId1;
    }

    public void setStudentId1(String studentId1) {
        this.studentId1 = studentId1;
    }

    public String getStudentId2() {
        return studentId2;
    }

    public void setStudentId2(String studentId2) {
        this.studentId2 = studentId2;
    }

    public String getStudentId3() {
        return studentId3;
    }

    public void setStudentId3(String studentId3) {
        this.studentId3 = studentId3;
    }
}
