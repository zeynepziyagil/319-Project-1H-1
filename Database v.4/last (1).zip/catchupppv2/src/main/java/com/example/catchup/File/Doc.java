package com.example.catchup.File;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Review.ArtifactReview;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
public class Doc {

    //Unique ID for each dosument
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "doc_id")
    private Integer id;

    //other properties
    private String documentName;
    private String documentType;
    private String documentRole;

    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "group_id")
    private ProjectGroup group;

    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "assignment_id")
    private Assignment assignment;

    @JsonIgnore
    @OneToMany(mappedBy = "doc",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ArtifactReview> reviews;

    @Lob
    private byte[] data;

    public Doc() {
    }

    public Doc(String documentName,String documentType, byte[] data) {
        super();
        this.documentName = documentName;
        this.documentType = documentType;
        this.data = data;
        this.documentRole = "";
    }

    public Doc(String documentName, String documentRole,String documentType, byte[] data) {
        super();
        this.documentName = documentName;
        this.documentType = documentType;
        this.data = data;
        this.documentRole = documentRole;
    }


    public Integer getId() {
        return id;
    }

    public String getDocumentRole() {
        return documentRole;
    }

    public void setDocumentRole(String documentRole) {
        this.documentRole = documentRole;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public List<ArtifactReview> getReviews() {
        return reviews;
    }

    public void setReviews(List<ArtifactReview> reviews) {
        this.reviews = reviews;
    }
}
