package com.example.catchup.File;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.File.Doc;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Review.ArtifactReview;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

@Service
public interface DocService {

    Doc saveFile(MultipartFile file);

    Optional<Doc> findById(Integer id);

    void saveDoc(Doc doc);

    Optional<Doc> getFile(Integer id);

    List<Doc> getFiles();

    void updateGroup(ProjectGroup group, Integer id);

    void updateAssignment(Assignment assignment, Integer id);

    Integer getDocByIds(Long assignment_id, Long group_id);

    void updateReviews(List<ArtifactReview> reviews, Integer id);
}
