package com.example.catchup.Group;

import com.example.catchup.Course.Course;
import com.example.catchup.File.Doc;
import com.example.catchup.User.Student;
import com.example.catchup.User.User;
import com.example.catchup.User.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ProjectGroupServiceImpl implements ProjectGroupService{
    //properties
    private ProjectGroupRepository projectGroupRepository;
    @Autowired
    public void setProjectGroupRepository(ProjectGroupRepository projectGroupRepository) {
        this.projectGroupRepository = projectGroupRepository;
    }

    @Override
    public List<ProjectGroup> findAll(){
        return projectGroupRepository.findAll();
    }

    @Override
    public Optional<ProjectGroup> findById(Long id){
        return projectGroupRepository.findById(id);
    }

    @Override
    public void save(ProjectGroup projectGroup){
        projectGroupRepository.save(projectGroup);
    }

    @Override
    public void updateProjectGroupStudent(List<Student> students, int memberNum, Long id) {
        projectGroupRepository.updateProjectGroupStudent(students,memberNum,id);
    }

    @Override
    public void updateProjectGroupTA(String name, int maxMemNum, Long id) {
        projectGroupRepository.updateProjectGroupTA(name,maxMemNum,id);
    }

    @Override
    public int getTotalProjectGroupNum() {
        return projectGroupRepository.getTotalProjectGroupNum();
    }

    @Override
    public List<Long> getAllStudents(Long id) {
        return projectGroupRepository.getAllStudents(id);
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long id){
        projectGroupRepository.deleteProjectGroup(id);
    }

    @Override
    public String getNameById(Long id) {
        return projectGroupRepository.getNameById(id);
    }

    @Override
    public List<Long> getGroupId(Course course) {
        return projectGroupRepository.getGroupId(course);
    }

    @Override
    public void updateDocs(List<Doc> docs, Long id) {
        projectGroupRepository.updateDocs(docs,id);
    }
}
