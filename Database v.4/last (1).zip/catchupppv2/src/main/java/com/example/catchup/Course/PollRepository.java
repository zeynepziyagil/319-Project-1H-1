package com.example.catchup.Course;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.Date;
import java.util.List;
@Transactional
@Repository
public interface PollRepository extends JpaRepository<Poll,Long> {
    @Modifying
    @Query("update Poll p set p.name = :name, p.duration = :duration, p.questionNum = :questionNum,p.questions =:questions where p.id = :id")
    void updatePoll( @Param("name") String name, @Param("duration") Duration duration,@Param("questionNum") int questionNum,@Param("questions") List<Question> questions,@Param("id") Long id);

    @Query("select count (id) from Poll ")
    int getTotalPollNum();

    @Modifying
    @Query("delete from Poll p where p.id = :id")
    void deletePoll(@Param("id") Long id);

    @Query("select questions from Poll")
    List<Long> getQuestions(@Param("id") Long id);

    @Query("select p.id from Poll p where p.course = :course")
    List<Long> getPollId(@Param("course") Course course);

}
