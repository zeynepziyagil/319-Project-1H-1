package com.example.catchup.Review;

import com.example.catchup.User.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
@Repository
public interface PeerReviewRepository extends JpaRepository<PeerReview,Long> {

    @Query("select count (id) from PeerReview ")
    int getTotalPReviewNum();


    @Query("select pr.feedback from PeerReview pr where pr.id = : id")
    String getFeedback(Long id);

    @Modifying
    @Query("delete from PeerReview pr where pr.id = :id")
    void deletePReview(@Param("id") Long id);

    @Query("select pr.grade from PeerReview pr where pr.id = :id")
    List<Double> getGrade(@Param("id") Long id);

    @Query("select pr.feedback from PeerReview  pr where pr.rater =:rater")
    List<String> getGivenFeedbacks(@Param("rater") Student rater);

}
