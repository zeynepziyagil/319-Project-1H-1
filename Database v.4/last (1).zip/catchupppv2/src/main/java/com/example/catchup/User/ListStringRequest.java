package com.example.catchup.User;

import com.example.catchup.Group.ProjectGroup;

import java.util.List;

public class ListStringRequest {

    public List<ProjectGroup> getRequests() {
        return requests;
    }

    public void setRequests(List<ProjectGroup> requests) {
        this.requests = requests;
    }

    private List<ProjectGroup> requests;
}
