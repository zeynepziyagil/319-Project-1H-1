package com.example.catchup;

import com.example.catchup.Review.PeerReview;
import com.example.catchup.Review.PeerReviewService;
import com.example.catchup.User.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class PeerReviewController {
    private final PeerReviewService peerReviewService;
    private final UserService userService;
    private final StudentService studentService;


    public PeerReviewController(PeerReviewService peerReviewService, UserService userService, StudentService studentService) {
        this.peerReviewService = peerReviewService;
        this.userService = userService;
        this.studentService = studentService;
    }

    @PostMapping("/make-peer-review/{mail}")
   public void makePeerReview(@RequestBody PeerReviewRequest prq, @PathVariable String mail) {
        if(userService.getRoleById(userService.getIdByMail(mail)).equals("student"))
        {
            Long  idx = Long.parseLong(prq.getStudentId());
            Student receiverStu = studentService.findById(idx).get();
            Student rater = studentService.findById(userService.getIdByMail(mail)).get();
            PeerReview pr = new PeerReview(prq.getComment(),prq.getGrade(),rater,receiverStu);
           List<PeerReview> receviersrev = receiverStu.getReviews();
           receviersrev.add(pr);
           peerReviewService.save(pr);
           studentService.updateReviews(receviersrev,idx);
        }
    }

    @GetMapping("/get-given-feedbacks/{email}")
    public List<String> getGivenFeedbacks(@PathVariable("email") String email)
    {
        Student u = studentService.findById(userService.getIdByMail(email)).get();
        return peerReviewService.getGivenFeedbacks(u);
    }



}

