package com.example.catchup.User;

import com.example.catchup.Course.Course;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Review.PeerReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
@Repository
public interface StudentRepository extends JpaRepository<Student,Long>{
   /* @Modifying
    @Query("update Student s set s.name = :name, s.surname = :surname,s.password = :password, s.course = :course, s.conversations = :conversations,s.currentSemester = :currentSemester, s.group = :group, s.department = :department, s.averagePeerGrade = :averagePeerGrade, s.reviews = :reviews where s.studentId = :studentId")
    void updateStudent(@Param("name") String name, @Param("surname") String surname , @Param("password") String password, @Param("course") Course course, @Param("conversations") List<Long> conversations, @Param("currentSemester") int currentSemester, @Param("group") ProjectGroup group, @Param("department") String department, @Param("averagePeerGrade") double averagePeerGrade, @Param("reviews") List<PeerReview> reviews, @Param("studentId")  Long studentId);
*/
    @Query("select count (studentId) from Student")
    int getTotalStudentNum();

   // @Query(value = "select s.studentId from Student s where s.name = : name")
   // List<Long> findStudentsByUserName(@Param("name") String name);

    @Modifying
    @Query("delete from Student s where s.studentId = :studentId")
    void deleteStudent(@Param("studentId") Long studentId);

    @Modifying
    @Query("update Student s  set s.group = :group where s.studentId = :studentId")
    void addGroupById(@Param("group") ProjectGroup group,@Param("studentId") Long studentId);

    @Modifying
    @Query("update Student s set s.course = :courseList where s.studentId = :studentId")
    void addCourseById(@Param("courseList") Course course,@Param("studentId") Long studentId);

    @Query("select s.group from Student s where s.id = :id")
    ProjectGroup getGroupsById(@Param("id") Long id);

    @Modifying
    @Query(value = "update Student s set s.reviews =:reviews where s.studentId = :studentId", nativeQuery = true)
    void addReviewById(@Param("reviews") List<PeerReview> reviews,@Param("studentId") Long studentId );

    @Modifying
    @Query("update Student s set s.group =:group where s.id = :id")
    void updateGroup(@Param("id") Long id,@Param("group") ProjectGroup group);

    @Query("select s.id from Student s where s.studentId = :studentId")
    Long findIdByStudentId(@Param("studentId") Long studentId);

    @Modifying
    @Query(value ="update Student s set s.reviews = :reviews where s.id = :id" , nativeQuery = true)
    void updateReviews(@Param("reviews") List<PeerReview> reviews,@Param("id") Long id);

    @Query("select s.studentId from Student s where s.id = :id")
    Long getStudentIdbyId(@Param("id") Long id);

}