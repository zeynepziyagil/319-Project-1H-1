package com.example.catchup.User;

public interface ReviewRequestStrategy {

}
