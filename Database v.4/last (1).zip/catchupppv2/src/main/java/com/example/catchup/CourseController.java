package com.example.catchup;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Assignment.AssignmentService;
import com.example.catchup.Course.*;
import com.example.catchup.File.Doc;
import com.example.catchup.File.DocService;
import com.example.catchup.Group.Advertisement;
import com.example.catchup.Group.AdvertisementService;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin("*")
public class CourseController {
    private final StudentService studentService;
    private final InstructorService instructorService;
    private final TeachingAssistantService teachingService;
    private final UserService userService;
    private final CourseService courseService;
    private final AssignmentService assignmentService;
    private final PollService pollService;
    private final ProjectGroupService projectGroupService;
    private final AnnouncementService announcementService;
    private final AdvertisementService advertisementService;
    private final RequestService requestService;
    private final DocService docService;

    @Autowired
    public CourseController(StudentService studentService, InstructorService instructorService, TeachingAssistantService teachingService, UserService userService, CourseService courseService, AssignmentService assignmentService, PollService pollService, ProjectGroupService projectGroupService, AnnouncementService announcementService, AdvertisementService advertisementService, RequestService requestService, DocService docService) {
        this.studentService = studentService;
        this.instructorService = instructorService;
        this.teachingService = teachingService;
        this.userService = userService;
        this.courseService = courseService;
        this.assignmentService = assignmentService;
        this.pollService = pollService;
        this.projectGroupService = projectGroupService;
        this.announcementService = announcementService;
        this.advertisementService = advertisementService;
        this.requestService = requestService;
        this.docService = docService;
    }


    @GetMapping("/coursePage/assignments/{mail}")
    public List<Assignment> getAssignments(@PathVariable("mail") String mail)
    {
        //Assignments
        User user = userService.findById(userService.getIdByMail(mail)).get();
        Long courseId = user.getCourses().getCode();
        List<Assignment> ass = new ArrayList<>(0);
        List<Long> ids = assignmentService.getAssignmentId(courseService.findById(courseId).get());
        for(int i = 0; i < ids.size(); i++ )
        {
            ass.add(assignmentService.findById(ids.get(i)).get());
        }
        return ass;
    }
    //Polls
    @GetMapping("/coursePage/{userMail}/poll")
    public List<Poll> getPolls(@PathVariable("userMail") String userMail)
    {
        //Polls
        User user = userService.findById(userService.getIdByMail("userMail")).get();
        Long courseId = user.getCourses().getCode();
        List<Poll> polls = new ArrayList<>(0);
        List<Long> ids = pollService.getPollId(courseService.findById(courseId).get());
        for(int i = 0; i < ids.size(); i++ )
        {
            polls.add(pollService.findById(ids.get(i)).get());
        }
        return polls;
    }

    //ProjectGroups
    @GetMapping("/coursePage/groups/{userMail}")
    public List<ProjectGroup> getProjectGroups(@PathVariable("userMail") String mail)
    {
        List<ProjectGroup> pg = new ArrayList<>(0);
        Long id = userService.getIdByMail(mail);
        List<Long> ids = projectGroupService.getGroupId(userService.getCourseById(id));
        for(int i = 0; i < ids.size(); i++ )
        {
            pg.add(projectGroupService.findById(ids.get(i)).get());
        }
        return pg;
    }

    //Announcements
    @GetMapping("/coursePage/announcement/{userMail}")
    public List<Announcement> getAnnouncements(@PathVariable("userMail") String userMail)
    {
        User user = userService.findById(userService.getIdByMail(userMail)).get();
        Long courseId = user.getCourses().getCode();
        List<Announcement> ann = new ArrayList<>(0);
        List<Long> ids = announcementService.getAnnouncementId(courseService.findById(courseId).get());
        for(int i = 0; i < ids.size(); i++ )
        {
            ann.add(announcementService.findById(ids.get(i)).get());
        }
        return ann;
    }

   //Advertisements
    @GetMapping("/coursePage/advertisement/{userMail}")
    public List<Advertisement> getAds(@PathVariable("userMail") String userMail)
    {
        User user = userService.findById(userService.getIdByMail(userMail)).get();
        Long courseId = user.getCourses().getCode();
        List<Advertisement> ad = new ArrayList<>(0);
        List<Long> ids = advertisementService.getAdvertisementId(courseService.findById(courseId).get());
        for(int i = 0; i < ids.size(); i++ )
        {
            ad.add(advertisementService.findById(ids.get(i)).get());
        }
        return ad;
    }

    //give advertisement
    @PostMapping("/make-advertisement/{email}")
    public void makeAdvertisement(@RequestBody AdvertisementRequest a, @PathVariable String email)
    {
        Advertisement advertisement = new Advertisement(a.getTitle(),a.getDescription());
        User user =  userService.findById(userService.getIdByMail(email)).get();
        //find the course of the student
        Course c = userService.getCourseById(user.getId());
        if(user.getRole().equals("student"))
        {
            advertisement.setStudentOwner(studentService.findById(user.getId()).get());
            advertisement.setCourse(c);
            advertisementService.save(advertisement);
            //coursa advert
            //getCourse
            Course course = user.getCourses();
            List<Advertisement> ads = course.getAds();
            ads.add(advertisement);
            course.setAds(ads);
            courseService.updateAds(course.getAds(), course.getCode());
        }
    }

    //poll creation for instructor
    @PostMapping("/create-poll/{email}")
    public void createPoll(@RequestBody Poll poll, @PathVariable String email){

    }

    //poll submisson for student
    //add announcement for instructor
    //group formation request for students
    @PostMapping("/create-formation-request/{email}")
    public void requestGroupFormation(@RequestBody GetRequest req, @PathVariable("email") String email )
    {
        //find assistant
        TeachingAssistant u = teachingService.findById(userService.getIdByMail(email)).get();
        //form request
        Request request = new Request(req.getTitle(),req.getText(),u);
        requestService.save(request);
    }
    //get group formation info for TA
    @GetMapping("/coursePage/TA/requests/{email}")
    public List<Request> getRequests(@PathVariable("email") String email)
    {
        TeachingAssistant user = teachingService.findById(userService.getIdByMail(email)).get();
        List<Request>  reqs = new ArrayList<>(0);
        List<Long> ids = requestService.getRequestId(user);
        for(int i = 0; i < ids.size(); i++ )
        {
            reqs.add(requestService.findById(ids.get(i)).get());
        }
        return reqs;
    }

   @PostMapping("/give-assignment/{email}")
    public void giveAssignment(@RequestBody AssignmentRequest ar ,@PathVariable("email") String email){
        Instructor instructor = instructorService.findById(userService.getIdByMail(email)).get();
        Course course = instructor.getCourses();
        Assignment ass = new Assignment(ar.getName(), ar.getDeadline(),ar.getTitle(), ar.getDescription());
        ass.setCourse(course);
        assignmentService.save(ass);
       /////////////////////
       List<Assignment> asses = course.getAssignments();
       asses.add(ass);
       courseService.updateAssignments(asses,course.getCode());
   }

   @GetMapping("/give-assign-by-assign-id/{assign_id}")
    public Assignment returnAssignment(@PathVariable("assign_id") String assign_id)
   {
       Long a_id = Long.parseLong(assign_id);
       return assignmentService.findById(a_id).get();
   }
}
