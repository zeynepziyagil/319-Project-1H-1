package com.example.catchup.User;

import com.example.catchup.Course.Course;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Review.PeerReview;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
public interface RequestService {
    List<Request> findAll();

    Optional<Request> findById(Long id);

    void save(Request request);

    void delete(Long id);

    List<Long> getRequestId(TeachingAssistant teachingAssistant );
}
