package com.example.catchup.File;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.File.Doc;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Review.ArtifactReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Transactional
@Repository
public interface DocRepository extends JpaRepository<Doc,Integer> {
    @Modifying
    @Query("update Doc d set d.group = :group where d.id = :id ")
    void updateGroup(@Param("group") ProjectGroup group, @Param("id") Integer id);

    @Modifying
    @Query("update Doc d set d.assignment = :assignment where d.id = :id ")
    void updateAssignment(@Param("assignment") Assignment assignment, @Param("id") Integer id);

    @Modifying
    @Query("update Doc d set d.reviews = :reviews where d.id = :id ")
    void updateReviews(@Param("reviews") List<ArtifactReview> reviews, @Param("id") Integer id);

    @Query("select d.id from Doc d where d.group.id = :group_id and d.assignment.id = :assignment_id ")
    Integer getDocByIds(@Param("assignment_id") Long assignment_id, @Param("group_id") Long group_id);
}

