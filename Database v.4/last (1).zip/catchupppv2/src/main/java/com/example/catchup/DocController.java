package com.example.catchup;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Assignment.AssignmentService;
import com.example.catchup.File.Doc;
import com.example.catchup.File.DocService;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
@RestController
@CrossOrigin("*")
public class DocController {

    //properties
    private final DocService docService;
    private final StudentService studentService;
    private final UserService userService;
    private final InstructorService instructorService;
    private final ProjectGroupService groupService;
    private final AssignmentService assignmentService;

    @Autowired
    public DocController(DocService docService, StudentService studentService, UserService userService, InstructorService instructorService, ProjectGroupService groupService, AssignmentService assignmentService) {
        this.docService = docService;
        this.studentService = studentService;
        this.userService = userService;
        this.instructorService = instructorService;
        this.groupService = groupService;
        this.assignmentService = assignmentService;
    }
/*
    @GetMapping(value = "/document/upload/see/{email}")
    public List<Doc> getDocs(@PathVariable("email") String email){
        List<Doc> docs = docService.getFiles();
        model.addAttribute("docs",docs);
    }
*/
@GetMapping(value = "/show-doc-with-groupandassign/{assign_id}/{group_id}")
public Doc showGroupArtifactAssign(@PathVariable("assign_id")  String assign_id,@PathVariable("group_id")  String group_id)
{
    Long a_id = Long.parseLong(assign_id);
    Long g_id = Long.parseLong(group_id);
    Integer d_id = docService.getDocByIds(a_id,g_id);
    return docService.findById(d_id).get();
}

    @GetMapping(value = "/show-uploaded-artifact-groups/{group_id}")
    public List<Doc> showGroupArtifacts(@PathVariable("group_id")  String group_id)
    {
        Long g_id = Long.parseLong(group_id);
        ProjectGroup pg = groupService.findById(g_id).get();
        List<Doc> artofgroup =  pg.getDocs();
        return artofgroup;
    }

    @GetMapping(value = "/show-instr-alldocsofassign/{assignment_id}")
    public List<Doc> showAllDocAssign(@PathVariable("assignment_id") String assignment_id)
    {
        Long ass_id = Long.parseLong(assignment_id);
        Assignment ass = assignmentService.findById(ass_id).get();
        return ass.getDoc();
    }

    @PostMapping(value = "/uploadArtifactFiles/{email}/{assignment_id}")
    public void uploadArtifactMultipleFiles(@RequestParam("myFile") MultipartFile files,@PathVariable("email") String email,@PathVariable("assignment_id") String assignment_id){
       System.out.println("1");
        Long ass_id = Long.parseLong(assignment_id);
        Assignment ass = assignmentService.findById(ass_id).get();
        List<Doc> docsofassign = ass.getDoc();

        Student u =  studentService.findById(userService.getIdByMail(email)).get();

        ProjectGroup group = studentService.getGroupsById(userService.getIdByMail(email));
        List<Doc> docsofgroup = group.getDocs();

            System.out.println("2");
            String docName = files.getOriginalFilename();
            try{
                System.out.println("3");
                Doc doc = new Doc(docName,files.getContentType(), files.getBytes());
                docsofgroup.add(doc);
                docsofassign.add(doc);
                docService.saveDoc(doc);
                docService.updateGroup(group, doc.getId() );
                //update the assignment of the doc
                docService.updateAssignment(ass, doc.getId());
            }catch (Exception e){
                System.out.println("4");
                e.printStackTrace();
            }
        System.out.println("5");
       groupService.updateDocs(docsofgroup, group.getId());
       //update the doc of the assignment
        assignmentService.updateDocs(docsofassign, ass.getId());
       System.out.println("6");
    }
/*
    @PostMapping(value = "/uploadAssignmentFiles/{email}/")
    public  void  uploadAssignmentMultipleFiles(@RequestParam("myFile") MultipartFile files,@PathVariable("email") String email){
        Student u =  studentService.findById(userService.getIdByMail(email)).get();
        ProjectGroup group = studentService.getGroupsById(userService.getIdByMail(email));
        List<Doc> docsofgroup = group.getDocs();
        String docName = files.getOriginalFilename();
        try{
            Doc doc = new Doc(docName,files.getContentType(), files.getBytes());
            docsofgroup.add(doc);
            docService.saveDoc(doc);
            docService.updateGroup(group, doc.getId() );
        }catch (Exception e){
            e.printStackTrace();
        }
        groupService.updateDocs(docsofgroup, group.getId());
    }
*/
    @GetMapping("/downloadFile/{str}")
    public ResponseEntity<ByteArrayResource> downloadFile(@PathVariable String str){
        Integer fileId = Integer.parseInt(str);
        Doc doc = docService.getFile(fileId).get();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(doc.getDocumentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION,"attachment:filename=\""+doc.getDocumentName()+"\"")
                .body(new ByteArrayResource(doc.getData()));
    }

}
//instructor create course +
//instrucctor give assignmnet+-

//instructor assignment see for everyone+-
//upload artifact to assignment+-
//see artifact on assignment for all roles+-