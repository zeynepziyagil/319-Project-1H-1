package com.example.catchup.Group;
import com.example.catchup.Course.Course;
import com.example.catchup.File.Doc;
import com.example.catchup.User.Student;
import com.example.catchup.User.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
@Repository
public interface ProjectGroupRepository extends JpaRepository<ProjectGroup,Long>  {
    @Modifying
    @Query("update ProjectGroup pg set  pg.students = :students, pg.memberNum = :memberNum where pg.id = :id")
    void updateProjectGroupStudent( @Param("students") List<Student> students,@Param("memberNum") int memberNum ,@Param("id")  long id);

    @Modifying
    @Query("update ProjectGroup pg set pg.name = :name, pg.maxMemberNum = :maxMemberNum where pg.id = :id")
    void updateProjectGroupTA(@Param("name") String name, @Param("maxMemberNum") int maxMemberNum, @Param("id")  long id);

    @Query("select count (id) from ProjectGroup")
    int getTotalProjectGroupNum();

    @Modifying
    @Query("delete from ProjectGroup pg where pg.id = :id")
    void deleteProjectGroup(@Param("id") Long id);

    @Query("select students from ProjectGroup")
    List<Long>  getAllStudents(Long id);

    @Query("select g.name from ProjectGroup  g where g.id =:id")
    String getNameById(@Param("id") Long id);

    @Query("select pg.id from ProjectGroup pg where pg.course = :course")
    List<Long> getGroupId(@Param("course") Course course);

    @Modifying
    @Query("update ProjectGroup pg set pg.docs = :docs where pg.id = :id")
    void updateDocs(@Param("docs") List<Doc> docs, @Param("id") Long id);
}
