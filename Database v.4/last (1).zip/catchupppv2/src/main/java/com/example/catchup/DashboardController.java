package com.example.catchup;

import com.example.catchup.Course.Course;
import com.example.catchup.Course.CourseService;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.Long.parseLong;

@RestController
@CrossOrigin("*")
public class DashboardController {
    private final StudentService studentService;
    private final InstructorService instructorService;
    private final TeachingAssistantService teachingService;
    private final UserService userService;
    private final CourseService courseService;
    private final ProjectGroupService projectGroupService;

    @Autowired
    public DashboardController(StudentService studentService, InstructorService instructorService, TeachingAssistantService teachingService, UserService userService, CourseService courseService, ProjectGroupService projectGroupService) {
        this.studentService = studentService;
        this.instructorService = instructorService;
        this.teachingService = teachingService;
        this.userService = userService;
        this.courseService = courseService;
        this.projectGroupService = projectGroupService;
    }

    @GetMapping("dashboard/{emailUser}")
    public Course getCoursesDashboard(@PathVariable("emailUser") String mail){ //???? LONG????//Not give any error in java
        System.out.println("burası1");
        Long id = userService.getIdByMail(mail);
        System.out.println("burası2");
        return userService.getCourseById(id);
    }

    @GetMapping("/dashboard/group/{emailUser}")//bak duruma göre
    public ProjectGroup getGroupsDashboard(@PathVariable("emailUser") String mail){
       //check if the id belongs student or not
        Long id = userService.getIdByMail(mail);
        if(userService.getRoleById(id).equals("student"))
        {
            return studentService.getGroupsById(id);
        }
        return null;
    }



    @GetMapping("dashboard/enroll-role/{emailUser}")
    public StringRequest getRoleDashboard(@PathVariable("emailUser") String mail){ //???? LONG????//Not give any error in java
        Long id = userService.getIdByMail(mail);
        String role = userService.findById(id).get().getRole();
        StringRequest sr = new StringRequest();
        sr.setStr(role);

        System.out.println(sr.getStr());
        return sr;
    }


    //enroll the course for students and tas
    @PostMapping("/dashboard/enroll-course/{emailUser}")
    public void enrollCourse(@RequestBody StringRequest ccode,@PathVariable String emailUser)
    {
        System.out.println("enrollamadı");
        String coursecode = ccode.getStr();
        Long courseCode =  Long.parseLong(coursecode);
        //find user by mail
        User user =  userService.findById(userService.getIdByMail(emailUser)).get();
        if(user.getRole().equals("student") || user.getRole().equals("teaching assistant")) {
            //find the course from course code
            Course course = courseService.findById(courseCode).get();
            //add course to the user
            userService.addCourseToUser(course, user.getId());

            //add user to the course
            List<User> usersOfCourse = course.getUsers();
           // User newuser = new User(user.getName(),user.getSurname(),user.getMail(),user.getPassword(),user.getRole());
            usersOfCourse.add( user);
            course.setUsers(usersOfCourse);
           courseService.updateUsers(course.getUsers(), courseCode);
        }

    }
    //create course for instructor an make him the user of this coursse
    @PostMapping("/dashboard/create-course/{emailUser}")
    public void createCourse(@RequestBody StringRequest sq,@PathVariable String emailUser)
    {
        System.out.println(sq.getStr());
        Course course = new Course(sq.getStr());

        //get the user
        Instructor user =  instructorService.findById(userService.getIdByMail(emailUser)).get();
        //add course to the database
        courseService.save(course);
        Long code =  course.getCode();
        //add instructor to this course
        userService.addCourseToUser(course, user.getId());
        //add user to the course
        List<User> usersOfCourse = course.getUsers();
        usersOfCourse.add(user);
        courseService.updateUsers(usersOfCourse, code);
    }

    @GetMapping("/get-course-code/instructor/{email}")
    public StringRequest getCourseCode(@PathVariable String email)
    {
        Instructor user =  instructorService.findById(userService.getIdByMail(email)).get();
        Long code = user.getCourses().getCode();
        String str2 = "" + code;
        StringRequest sqr = new StringRequest();
        sqr.setStr(str2);
        return sqr;
    }
}
