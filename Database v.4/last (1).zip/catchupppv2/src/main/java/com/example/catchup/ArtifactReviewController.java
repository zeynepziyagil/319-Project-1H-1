package com.example.catchup;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Assignment.AssignmentService;
import com.example.catchup.File.Doc;
import com.example.catchup.File.DocService;
import com.example.catchup.Review.ArtifactReview;
import com.example.catchup.Review.ArtifactReviewService;
import com.example.catchup.User.ArtifactReviewRequest;
import com.example.catchup.User.StudentService;
import com.example.catchup.User.User;
import com.example.catchup.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class ArtifactReviewController {

    private final UserService userService;
    private final StudentService studentService;
    private final DocService docService;
    private final ArtifactReviewService reviewService;
    private final AssignmentService assignmentService;

    @Autowired
    public ArtifactReviewController(UserService userService, StudentService studentService, DocService docService, ArtifactReviewService reviewService, AssignmentService assignmentService) {
        this.userService = userService;
        this.studentService = studentService;
        this.docService = docService;
        this.reviewService = reviewService;
        this.assignmentService = assignmentService;
    }

    @PostMapping("/makeArtifactReview/{mail}")
    public void makeArtifactReview(@RequestBody ArtifactReviewRequest arr, @PathVariable("mail") String mail)
    {
        Integer d_id = Integer.parseInt(arr.getDocId());
        Doc d = docService.findById(d_id).get();
        User u = userService.findById(userService.getIdByMail(mail)).get();
        ArtifactReview ar = new ArtifactReview(arr.getComment(),arr.getGrade(),u,d);
        reviewService.save(ar);
        List<ArtifactReview> ars = d.getReviews();
        ars.add(ar);
        docService.updateReviews(ars, d.getId());
    }
/*
    @GetMapping("/show-artifact-reviews/{}/{assignment_id}")
    public void showArtifactReviews(@PathVariable("mail") String mail, @PathVariable("assignment_id") String assignmentId )
    {
        Long a_id = Long.parseLong(assignmentId);
        Assignment ass = assignmentService.findById(a_id).get();
        List<Doc> d = ass.getDoc();


    }
    */
}
