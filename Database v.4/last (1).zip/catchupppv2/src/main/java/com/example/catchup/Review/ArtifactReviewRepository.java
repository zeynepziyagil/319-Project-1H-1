package com.example.catchup.Review;


import com.example.catchup.File.Doc;
import com.example.catchup.User.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
@Repository
public interface ArtifactReviewRepository extends JpaRepository<ArtifactReview,Long> {

    @Query("select count (id) from ArtifactReview")
    int getTotalAReviewNum();

    @Modifying
    @Query("delete from ArtifactReview pr where pr.id = :id")
    void deleteAReview(@Param("id") Long id);

    @Query("select ar.feedback from ArtifactReview ar where ar.id = :id")
    String getFeedbacks(Long id);

    @Modifying
    @Query("update ArtifactReview ar set ar.grade = :grade where ar.id = :id")
    void updateArtifactReviewGrade(@Param("grade") double grade, @Param("id") Long id);
}
