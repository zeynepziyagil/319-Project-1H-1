package com.example.catchup.User;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RequestServiceImpl  implements RequestService{

    private RequestRepository requestRepository;

    public RequestServiceImpl(RequestRepository requestRepository) {
        this.requestRepository = requestRepository;
    }

    @Override
    public List<Request> findAll() {
        return requestRepository.findAll();
    }

    @Override
    public Optional<Request> findById(Long id) {
        return requestRepository.findById(id);
    }

    @Override
    public void save(Request request) {
        requestRepository.save(request);
    }

    @Override
    public void delete(Long id) {
        requestRepository.delete(id);
    }

    @Override
    public List<Long> getRequestId(TeachingAssistant teachingAssistant) {
        return requestRepository.getRequestId(teachingAssistant);
    }
}
