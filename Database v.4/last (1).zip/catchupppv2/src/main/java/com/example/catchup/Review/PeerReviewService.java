package com.example.catchup.Review;

import com.example.catchup.User.Student;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface PeerReviewService
{
    List<PeerReview> findAll();

    Optional<PeerReview> findById(Long id);

    void save(PeerReview peerReview);

    void delete(Long id);

    String getFeedback(Long id);

    List<Double> getGrade(Long id);

    int getTotalPeerReviewNum();

    List<String> getGivenFeedbacks(Student rater);


}
