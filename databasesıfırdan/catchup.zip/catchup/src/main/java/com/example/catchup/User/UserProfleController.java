package com.example.catchup.User;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/profile")
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@CrossOrigin("*")
public class UserProfleController {
    private final UserService userService;
    @Autowired
    public UserProfleController(UserService userService)
    {
        this.userService =userService;
    }
    @GetMapping
    public User getUserById(){
      return userService.findById(1L).get();
    }

    public void signup(String name, String surname, String mail, String password,String role){
        userService.save(new User(name,surname,mail,password,role));
    }
}
