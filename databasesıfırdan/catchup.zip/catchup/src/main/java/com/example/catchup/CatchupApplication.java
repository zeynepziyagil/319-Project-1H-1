package com.example.catchup;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Assignment.AssignmentRepository;
import com.example.catchup.Course.*;
import com.example.catchup.Group.Advertisement;
import com.example.catchup.Group.AdvertisementRepository;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupRepository;
import com.example.catchup.User.Student;
import com.example.catchup.User.StudentRepository;
import com.example.catchup.User.User;
import com.example.catchup.User.UserRepository;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


@Configuration
@EnableJpaRepositories(basePackages = {
        "com.example.catchup.Course", "com.example.catchup.Group", "com.example.catchup.User"
})
@SpringBootApplication
public class CatchupApplication {

    public static void main(String[] args) {
        SpringApplication.run(CatchupApplication.class, args);
    }

    @Bean
    ApplicationRunner applicationRunner(CourseRepository Repository){
        return args -> {
            Announcement announcement = new Announcement("A1","A2");
            Announcement announcement2 = new Announcement("A2","A3");
            Announcement announcement3 = new Announcement("A5","A4");

            Course course = new Course("CS202");
            List<Announcement> ann = course.getAnnouncements();
            ann.add(announcement);
            course.setAnnouncements(ann);
            course.getAnnouncements().add(announcement2);
            course.setAnnouncements(course.getAnnouncements());
            course.getAnnouncements().add(announcement3);
            course.setAnnouncements(course.getAnnouncements());
           Repository.save(course);
        };
    }
}