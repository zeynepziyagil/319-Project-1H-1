package com.example.catchup;

import com.example.catchup.Course.CourseService;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.InstructorService;
import com.example.catchup.User.StudentService;
import com.example.catchup.User.TeachingAssistantService;
import com.example.catchup.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("sign")
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@CrossOrigin("*")

public class DashboardController {
    private final StudentService studentService;
    private final InstructorService instructorService;
    private final TeachingAssistantService teachingService;
    private final UserService userService;
    private final CourseService courseService;
    private final ProjectGroupService projectGroupService;

    @Autowired
    public DashboardController(StudentService studentService, InstructorService instructorService, TeachingAssistantService teachingService, UserService userService, CourseService courseService, ProjectGroupService projectGroupService) {
        this.studentService = studentService;
        this.instructorService = instructorService;
        this.teachingService = teachingService;
        this.userService = userService;
        this.courseService = courseService;
        this.projectGroupService = projectGroupService;
    }

    @GetMapping("/dashboard/{id}")
    public List<String> getCoursesDashboard(@PathVariable("id") Long id){ //???? LONG????//Not give any error in java
            List<Long> courses = userService.getCourseListById(id);
            List<String> courseNames = new ArrayList<>(0);
            for(int i = 0; i < courses.size(); i++)
            {
                courseNames.add(courseService.getNameById(courses.get(i)));
            }
        return courseNames;
    }

    @GetMapping("/dashboard/{id}/1") //çalışıyo mu bak
    public List<String> getGroupsDashboard(@PathVariable("id") Long id){
       //check if the id belongs student or not
        List<String> groupNames = new ArrayList<>(0);
        if(userService.getRoleById(id).equals("student"))
        {
            //get the groups of the student
            List<Long> groups = studentService.getGroupsById(id);
            for(int i = 0; i < groups.size(); i++)
            {
                groupNames.add(projectGroupService.getNameById(groups.get(i)));
            }
        }
        return groupNames;
    }

}
