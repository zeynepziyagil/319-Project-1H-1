package com.example.catchup.User;

import java.util.List;
import java.util.Optional;

public interface InstructorService {
    List<Instructor> findAll();

    Optional<Instructor> findById(Long id);

    void save(Instructor instructor);

    void deleteInstructor(Long id);

    void updateInstructor( String name, String surname, String password, List<Long> courseList, List<Long> conversations, String officeLocation, TimeTable timeTable,Long id);

    int getTotalInstructorNum();

    Long getIdByEmail(String mail);
}
