package com.example.catchup.Course;

import com.vladmihalcea.hibernate.type.array.ListArrayType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@TypeDef(
        name = "list-array",
        typeClass = ListArrayType.class
)
public class Poll {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="poll_id")
    private Long id;
    //properties
    private String name;
    private Duration duration;

    @ManyToOne
    @JoinColumn(name = "course_code")
    private Course course;

    private int questionNum;

    @OneToMany(mappedBy = "poll",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Question> questions;

    public Poll() {
    }

    public Poll(String name, Duration duration, int questionNum) {
        this.name = name;
        this.duration = duration;
        this.questionNum = questionNum;
        this.questions = new ArrayList<>(0);
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Duration getDuration() {
        return duration;
    }

    public int getQuestionNum() {
        return questionNum;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    @Override
    public String toString() {
        return "Poll{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", duration=" + duration +
                ", questionNum=" + questionNum +
                ", questions=" + questions +
                '}';
    }
}

