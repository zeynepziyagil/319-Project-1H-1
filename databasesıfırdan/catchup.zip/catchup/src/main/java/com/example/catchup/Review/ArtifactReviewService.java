package com.example.catchup.Review;

import com.example.catchup.File.Doc;
import com.example.catchup.User.User;

import java.util.List;
import java.util.Optional;

public interface ArtifactReviewService {
    List<ArtifactReview> findAll();

    Optional<ArtifactReview> findById(Long id);

    void save(ArtifactReview artifactReview);

    void delete(Long id);

    void updateArtifactReview(String name, List<String> feedback, String deadline, double grade, int questionNum, User rater, Doc artifact, Long id);

    int getTotalArtifactReviewNum();

    List<String> getFeedbacks(Long id);

    void updateArtifactReviewGrade(double grade, Long id);
}
