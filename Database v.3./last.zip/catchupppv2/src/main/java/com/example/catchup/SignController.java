package com.example.catchup;

import com.example.catchup.User.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
public class SignController {

    private final StudentService studentService;
    private final InstructorService instructorService;
    private final TeachingAssistantService teachingService;
    private final UserService userService;
    @Autowired
    public SignController(StudentService studentService, InstructorService instructorService, TeachingAssistantService teachingService,UserService userService) {
        this.studentService = studentService;
        this.instructorService = instructorService;
        this.teachingService = teachingService;
        this.userService =  userService;
    }
    //sign in
   @PostMapping("/sign-in")
   public User signIn(@RequestBody LogInRequest liq) {
       System.out.println("signine girdi");
       User u = new User();
        String mail = liq.getMail();
        String password = liq.getPassword();
        if( checkAccount(mail,password) )
        {
            return userService.findById(userService.getIdByMail(mail)).get();
        }
      return u;
    }

    @GetMapping("/sign-up") //KONUŞ
   public String signUp( int role) {
        if( role == 0)
            return "/sign-up/Student";
        else
            return "/sign-up/Instructor-TA";
    }

    @PostMapping("/sign-up/Student")
    public void signUpStudent( @RequestBody SignUpRequestStudent s) {
        //check existing mail from userService and confirm password
        if(!userService.checkExistEmail(s.getMail()) ){
            Student student = new Student(s.getName(),s.getSurname(),s.getMail(),s.getPassword(),s.getStudentId(),s.getGrade(),s.getDepartment());
            studentService.save(student);
        }
    }

    @PostMapping("/sign-up/Instructor-TA")
    public void signUpInstructorTA( @RequestBody SignUpRequestTaInst u) {
        //check existing mail from userService and confirm password
        if(!userService.checkExistEmail(u.getMail()) ){
            if(u.getRole().equals("instructor")){
                Instructor ins = new Instructor(u.getName(),u.getSurname(),u.getMail(),u.getPassword());
                instructorService.save(ins);
            }
            else if(u.getRole().equals("teaching assistant")){
                System.out.println("girdi");
                TeachingAssistant ta = new TeachingAssistant(u.getName(),u.getSurname(),u.getMail(),u.getPassword());
                teachingService.save(ta);
            }
        }
    }

   public boolean checkAccount(String mail, String password)
    {
        if(userService.getPasswordByMail(mail).equals(password))
            return true;
        return false;
    }
}
