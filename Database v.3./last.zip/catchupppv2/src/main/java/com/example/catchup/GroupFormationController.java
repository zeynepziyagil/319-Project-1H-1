package com.example.catchup;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Assignment.AssignmentService;
import com.example.catchup.Course.Course;
import com.example.catchup.Course.CourseService;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupRepository;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin("*")
public class GroupFormationController {
    private final UserService userService;
    private final StudentService studentService;
    private final ProjectGroupService projectGroupService;
    private final AssignmentService assignmentService;
    private final CourseService courseService;

    @Autowired
    public GroupFormationController(UserService userService, StudentService studentService, ProjectGroupRepository projectGroupRepository, ProjectGroupService projectGroupService, AssignmentService assignmentService, CourseService courseService) {
        this.userService = userService;
        this.studentService = studentService;
        this.projectGroupService = projectGroupService;
        this.assignmentService = assignmentService;
        this.courseService = courseService;
    }

    @GetMapping("/info-group/{mail}")
    public ProjectGroup getGroupInfo(@PathVariable String mail)
    {
        Student s = studentService.findById(userService.getIdByMail(mail)).get();
        return s.getGroups();
    }

    @GetMapping("/group-formation/group/{emailUser}")//bak duruma göre
    public List<Student> getGroupsStudent(@PathVariable("emailUser") String mail){
        //check if the id belongs student or not
        Long id = userService.getIdByMail(mail);
        if(userService.getRoleById(id).equals("student"))
        {
            ProjectGroup g =  studentService.getGroupsById(id);
            return g.getStudents();
        }
        return null;
    }



    @PostMapping("/form-assis-group/{mail}")
    void formGroupAssistant(@RequestBody RequestGroup rg, @PathVariable String mail) {
            //create project group
            ProjectGroup pg = new ProjectGroup(rg.getName(),rg.getMaxMemberNum(),rg.getMemberNum());
            List<Student> pgStudent = new ArrayList<>(0);
            Course c = userService.getCourseById(userService.getIdByMail(mail));

            if(!rg.getStudentId1().equals(""))
            {
                Long id1 = Long.parseLong(rg.getStudentId1());
                pgStudent.add(studentService.findById(studentService.findIdByStudentId(id1)).get());
            }

            if(!rg.getStudentId2().equals(""))
            {
                Long id2 = Long.parseLong(rg.getStudentId2());
                pgStudent.add(studentService.findById(studentService.findIdByStudentId(id2)).get());
            }

            if(!rg.getStudentId2().equals(""))
            {
                Long id3 = Long.parseLong(rg.getStudentId3());
                pgStudent.add(studentService.findById(studentService.findIdByStudentId(id3)).get());
            }
            //transfer string to long
        List<ProjectGroup> groupsOfCourse = c.getGroups();
        groupsOfCourse.add(pg);
        c.setGroups(groupsOfCourse);
        pg.setCourse(c);
        pg.setStudents(pgStudent);
        for(int i = 0 ; i < pgStudent.size(); i++) {
            System.out.println(pgStudent.get(i).getName());
            pgStudent.get(i).setGroups(pg);
        }
            projectGroupService.save(pg);

        courseService.updateGroups(groupsOfCourse,c.getCode());

        for(int i = 0 ; i < pgStudent.size(); i++) {
            studentService.updateGroup(pgStudent.get(i).getId(),pg);
        }
    }

    @PostMapping("/add-member-group/{mail}")
    void addMemberToGroup(@RequestBody StringRequest str, @PathVariable String mail)
    {
        Long id = Long.parseLong(str.getStr());
        Student addedStudent = studentService.findById(studentService.findIdByStudentId(id)).get();
        //find the admin
        Student admin = studentService.findById(userService.getIdByMail(mail)).get();
        //find the group of the admin
        ProjectGroup pg = admin.getGroups();
        //find the added student
        Long addedId = addedStudent.getId();
        if(userService.getRoleById(userService.getIdByMail(mail)).equals("student") && pg.getMemberNum() < pg.getMaxMemberNum())
        {
            //update group membernum, students, etc.
            List<Student> studentsofpg = pg.getStudents();
            studentsofpg.add(addedStudent);
            pg.setStudents(studentsofpg);
            //update addedstudent group from table
            studentService.updateGroup(addedId,pg);
            projectGroupService.updateProjectGroupStudent(pg.getStudents(), pg.getMemberNum() + 1, pg.getId());
        }
    }

     @PostMapping("/remove-member-group/{mail}")
     void removeMemberFromGroup(@RequestBody StringRequest str, @PathVariable String mail)
     {
         Long id = Long.parseLong(str.getStr());
         Student removedStudent = studentService.findById(studentService.findIdByStudentId(id)).get();
         //find the admin
         Student admin = studentService.findById(userService.getIdByMail(mail)).get();
         //find the group of the admin
         ProjectGroup pg = admin.getGroups();
         //find the removed student
         Long removedId = removedStudent.getId();
         if(userService.getRoleById(userService.getIdByMail(mail)).equals("student") && pg.getMemberNum() - 1 > 0)
         {
             //update group membernum, students, etc.
             List<Student> studentsofpg = pg.getStudents();
             studentsofpg.remove(removedStudent);
             pg.setStudents(studentsofpg);
             //update removedstudent group from table
             studentService.updateGroup(removedId,null);
             projectGroupService.updateProjectGroupStudent(pg.getStudents(), pg.getMemberNum() - 1, pg.getId());
         }
         else if (userService.getRoleById(userService.getIdByMail(mail)).equals("student") && pg.getMemberNum() - 1 <= 0)
         {
             studentService.updateGroup(removedId,null);
             projectGroupService.delete(pg.getId());
         }
     }

     @PostMapping("/make-deadline-requests/{mail}")
    void makeDeadlineRequest(@RequestBody String assignmentName, @PathVariable String mail) //you will only give the name of the assignment in assignment object
     {
         if(userService.getRoleById(userService.getIdByMail(mail)).equals("student")){
             //get assignment by using its name from its course
            //get student
            Student student = studentService.findById(userService.getIdByMail(mail)).get();
            //get course of this student
            Course course = student.getCourses();
            //get assignment
            List<Assignment> assignments = course.getAssignments();
            Assignment wantedassign = new Assignment();
            //find the assignment with given name
            for(int i = 0 ; i < assignments.size(); i++)
            {
                if(assignments.get(i).getName().equals(assignmentName))
                     wantedassign = assignments.get(i);
            }
            assignmentService.updateRequests(wantedassign.getRequests()+1, wantedassign.getId());
         }
     }

}
