package com.example.catchup.Course;
import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Course.Course;
import com.example.catchup.Group.Advertisement;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.User.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
@Repository
public interface CourseRepository  extends JpaRepository<Course,Long>  {
    @Modifying
    @Query("update Course c set c.name = :name, c.announcements = :announcements, c.ads = :ads, c.assignments = :assignments, c.polls = :polls,c.groups = :groups where c.code = :code")
    void updateCourse(@Param("name") String name, @Param("announcements") List<Announcement> announcements , @Param("ads") List<Advertisement> ads, @Param("assignments") List<Assignment> assignments, @Param("polls") List<Poll> polls, @Param("groups") List<ProjectGroup> groups, @Param("code")  Long code);

    @Query("select count (code) from Course")
    int getTotalCourseNum();

    @Modifying
    @Query("delete from Course c where c.code = :code")
    void deleteCourse(@Param("code") Long code);

    @Query("select announcements from Course")
    List<Announcement> getAnnouncements();

    @Query("select assignments from Course")
    List<Assignment> getAssignments();

    @Query("select ads from Course")
    List<Advertisement> getAdvertisements();

    @Query("select polls from Course")
    List<Poll> getPolls();

    @Query("select groups from Course")
    List<ProjectGroup> getGroups();

    @Query("select c.name from Course c where c.code = : code")
    String getNameById(@Param("code") Long code);

    @Modifying
    @Query("update Course c set c.users =:users where c.code =:code")
    void updateUsers(@Param("users") List<User> users, @Param("code") Long code);


    @Query("select c.code from Course c where c.name =:name")
    Long getCodeByName(@Param("name") String name);

    @Modifying
    @Query("update Course c set c.ads = :ads where c.code = :code")
    void updateAds(@Param("ads") List<Advertisement> ads, @Param("code") Long code);

    @Modifying
    @Query("update Course c set c.groups = :groups where c.code =:code")
    void updateGroups(@Param("groups") List<ProjectGroup> groups, @Param("code") Long code);
}
