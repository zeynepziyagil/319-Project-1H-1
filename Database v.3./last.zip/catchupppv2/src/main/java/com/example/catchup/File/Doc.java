package com.example.catchup.File;

import com.example.catchup.Group.ProjectGroup;
import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity
public class Doc {

    //Unique ID for each dosument
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    //other properties
    private String documentName;
    private String documentType;
    private String documentRole;

    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "group_id")
    private ProjectGroup projectGroup;

    @Lob
    private byte[] data;

    public Doc() {
    }

    public Doc(String documentName,String documentType, byte[] data) {
        super();
        this.documentName = documentName;
        this.documentType = documentType;
        this.data = data;
        this.documentRole = "";
    }

    public Doc(String documentName, String documentRole,String documentType, byte[] data) {
        super();
        this.documentName = documentName;
        this.documentType = documentType;
        this.data = data;
        this.documentRole = documentRole;
    }



    public Integer getId() {
        return id;
    }

    public String getDocumentRole() {
        return documentRole;
    }

    public void setDocumentRole(String documentRole) {
        this.documentRole = documentRole;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}
