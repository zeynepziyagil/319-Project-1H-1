package com.example.catchup.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Repository
public interface RequestRepository extends JpaRepository<Request,Long> {

    @Modifying
    @Query("delete from Request r where r.id = :id")
    void delete(@Param("id") Long id);

    @Query("select r.id from Request r where r.teachingAssistant = :teachingAssistant")
    List<Long> getRequestId(@Param("teachingAssistant") TeachingAssistant teachingAssistant );

}
