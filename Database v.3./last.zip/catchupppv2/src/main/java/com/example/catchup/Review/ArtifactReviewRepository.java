package com.example.catchup.Review;


import com.example.catchup.File.Doc;
import com.example.catchup.User.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
@Repository
public interface ArtifactReviewRepository extends JpaRepository<ArtifactReview,Long> {
    @Modifying
    @Query("update ArtifactReview ar set ar.name = :name, ar.feedback = :feedback, ar.deadline = :deadline, ar.grade = :grade, ar.questionNum = :questionNum, ar.rater = :rater, ar.artifact = :artifact where ar.id = :id")
    void updateAReview(@Param("name") String name, @Param("feedback") List<String> feedback, @Param("deadline") String deadline, @Param("grade") double grade, @Param("questionNum") int questionNum, @Param("rater") User rater, @Param("artifact") Doc artifact, @Param("id") Long id);

    @Query("select count (id) from ArtifactReview")
    int getTotalAReviewNum();

    @Modifying
    @Query("delete from ArtifactReview pr where pr.id = :id")
    void deleteAReview(@Param("id") Long id);

    @Query("select ar.feedback from ArtifactReview ar where ar.id = :id")
    List<String> getFeedbacks(Long id);

    @Modifying
    @Query("update ArtifactReview ar set ar.grade = :grade where ar.id = :id")
    void updateArtifactReviewGrade(@Param("grade") double grade, @Param("id") Long id);
}
