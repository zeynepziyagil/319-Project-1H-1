package com.example.catchup.User;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
public class Request{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String title;
    private String text;

    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "user_id")
    private TeachingAssistant teachingAssistant;

    public Request() {

    }

    public Request(String title, String text, TeachingAssistant teachingAssistant) {
        this.title = title;
        this.text = text;
        this.teachingAssistant = teachingAssistant;
    }

    public long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public TeachingAssistant getTeachingAssistant() {
        return teachingAssistant;
    }

    public void setTeachingAssistant(TeachingAssistant teachingAssistant) {
        this.teachingAssistant = teachingAssistant;
    }
}
