package com.example.catchup;

import com.example.catchup.File.Doc;
import com.example.catchup.File.DocService;
import com.example.catchup.User.Student;
import com.example.catchup.User.StudentService;
import com.example.catchup.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@EnableJpaRepositories("com.example.catchup.File")
@Controller
public class DocController {

    //properties
    private final DocService docService;
    private final StudentService studentService;
    private final UserService userService;

    @Autowired
    public DocController(DocService docService, StudentService studentService, UserService userService) {
        this.docService = docService;
        this.studentService = studentService;
        this.userService = userService;
    }
/*
    @RequestMapping(value = "/document/upload")
    public void get(Model model){
        List<Doc> docs = docService.getFiles();
        model.addAttribute("docs",docs);
    }
*/
    @PostMapping(value = "/uploadArtifactFiles/{email}")
    public void uploadMultipleFiles(@RequestParam("files") MultipartFile[] files,@PathVariable("email") String email){
        Student u =  studentService.findById(userService.getIdByMail(email)).get();
        for (MultipartFile file: files){
            docService.saveFile(file);
        }

    }

    @GetMapping("/downloadFile/{fileId}")
    public ResponseEntity<ByteArrayResource> downloadFile(@PathVariable Integer fileId){
        Doc doc = docService.getFile(fileId).get();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(doc.getDocumentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION,"attachment:filename=\""+doc.getDocumentName()+"\"")
                .body(new ByteArrayResource(doc.getData()));
    }

}
