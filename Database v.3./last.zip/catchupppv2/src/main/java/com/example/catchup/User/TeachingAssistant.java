package com.example.catchup.User;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.vladmihalcea.hibernate.type.array.ListArrayType;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@PrimaryKeyJoinColumn(name = "user_id")
@TypeDef(
        name = "list-array",
        typeClass = ListArrayType.class
)
public class TeachingAssistant extends User{

    //properties
    //CALENDAR ?
    private String officeLocation;

    @JsonIgnore
    @OneToMany(mappedBy = "teachingAssistant",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Request> requests;

    public TeachingAssistant(String name, String surname, String mail, String password) {
        super(name, surname, mail, password, "teaching assistant");
        this.officeLocation = "";
        requests = new ArrayList<>(0);
    }

    public void setOfficeLocation(String officeLocation) {
        this.officeLocation = officeLocation;
    }

    public List<Request> getRequests() {
        return requests;
    }

    public void setRequests(List<Request> requests) {
        this.requests = requests;
    }

    public TeachingAssistant() {
    }


    public String getOfficeLocation() {
        return officeLocation;
    }


    @Override
    public String toString() {
        return "TeachingAssistant{" +
                ", officeLocation='" + officeLocation + '\'' +
                '}';
    }
}
