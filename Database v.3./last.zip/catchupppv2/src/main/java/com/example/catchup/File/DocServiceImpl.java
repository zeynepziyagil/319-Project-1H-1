package com.example.catchup.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

@Service
public class DocServiceImpl implements DocService {

    //properties
    private DocRepository docRepository;

    @Autowired
    public void setDocRepository(DocRepository docRepository) {
        this.docRepository = docRepository;
    }

    @Override
    public Doc saveFile(MultipartFile file) {
        String docName = file.getOriginalFilename();
        try{
            Doc doc = new Doc(docName,file.getContentType(), file.getBytes());
            return docRepository.save(doc);
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Optional<Doc> getFile(Integer id) {
        return docRepository.findById(id);
    }

    @Override
    public List<Doc> getFiles() {
        return docRepository.findAll();
    }
}
