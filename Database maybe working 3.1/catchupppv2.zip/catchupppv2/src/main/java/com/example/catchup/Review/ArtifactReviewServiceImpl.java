package com.example.catchup.Review;

import com.example.catchup.File.Doc;
import com.example.catchup.User.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ArtifactReviewServiceImpl implements ArtifactReviewService{
    private ArtifactReviewRepository artifactReviewRepository;
    @Autowired
    public void setAssignmentRepository(ArtifactReviewRepository artifactReviewRepository) {
        this.artifactReviewRepository = artifactReviewRepository;
    }

    @Override
    public List<ArtifactReview> findAll() {
        return artifactReviewRepository.findAll();
    }

    @Override
    public Optional<ArtifactReview> findById(Long id) {
        return artifactReviewRepository.findById(id);
    }

    @Override
    public void save(ArtifactReview artifactReview) {
        artifactReviewRepository.save(artifactReview);
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long id){
        artifactReviewRepository.deleteAReview(id);
    }

    @Override
    public void updateArtifactReview(String name, List<String> feedback, String deadline, double grade, int questionNum, User rater, Doc artifact, Long id) {
        artifactReviewRepository.updateAReview(name,feedback,deadline, grade,questionNum,rater,artifact,id);
    }

    @Override
    public int getTotalArtifactReviewNum() {
        return artifactReviewRepository.getTotalAReviewNum();
    }

    @Override
    public List<String> getFeedbacks(Long id) {
        return artifactReviewRepository.getFeedbacks(id);
    }

    @Override
    public void updateArtifactReviewGrade(double grade, Long id) {
        artifactReviewRepository.updateArtifactReviewGrade(grade,id);
    }
}
