package com.example.catchup.File;

import com.example.catchup.File.Doc;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

@Service
public interface DocService {

    Doc saveFile(MultipartFile file);

    Optional<Doc> getFile(Integer id);

    List<Doc> getFiles();
}
