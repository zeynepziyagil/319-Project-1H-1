package com.example.catchup.Review;

import com.example.catchup.User.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
@Repository
public interface PeerReviewRepository extends JpaRepository<PeerReview,Long> {

    @Modifying
    @Query("update PeerReview pr set pr.name = :name, pr.feedback = :feedback, pr.grade = :grade, pr.questionNum = :questionNum, pr.rater = :rater, pr.reciever = :reciever where pr.id = :id")
    void updatePReview(@Param("name") String name, @Param("feedback") List<String> feedback, @Param("grade") double grade, @Param("questionNum") int questionNum, @Param("rater") Student rater, @Param("reciever") Student reciever);

    @Query("select count (id) from PeerReview ")
    int getTotalPReviewNum();

    @Query("select pr.questions from PeerReview pr where pr.id = : id")
    List<String> getQuestions(Long id);

    @Query("select pr.feedback from PeerReview pr where pr.id = : id")
    List<String> getFeedback(Long id);

    @Modifying
    @Query("delete from PeerReview pr where pr.id = :id")
    void deletePReview(@Param("id") Long id);

    @Query("select pr.grade from PeerReview pr where pr.id = :id")
    double getGrade(@Param("id") Long id);
}
