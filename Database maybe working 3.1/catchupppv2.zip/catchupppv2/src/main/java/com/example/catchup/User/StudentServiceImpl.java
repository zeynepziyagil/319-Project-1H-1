package com.example.catchup.User;

import com.example.catchup.Course.Course;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupServiceImpl;
import com.example.catchup.Review.PeerReview;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
public class StudentServiceImpl implements StudentService{
    //properties
    private StudentRepository studentRepository;

    @Autowired
    public void setStudentRepository(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Override
    public List<Student> findAll(){
        return studentRepository.findAll();
    }

    @Override
    public Optional<Student> findById(Long studentId){
        return studentRepository.findById(studentId);
    }

    @Override
    public void save(Student student){
        studentRepository.save(student);
    }

   /* @Override
    public void updateStudent(String name, String surname, String password, Course course, List<Long> conversations, int currentSemester, ProjectGroup group, String department, double averagePeerGrade, List<PeerReview> reviews, Long studentId) {
        studentRepository.updateStudent( name, surname,password, course, conversations, currentSemester, group, department, averagePeerGrade, reviews, studentId);
    }*/

    @Override
    public int getTotalStudentNum() {
        return studentRepository.getTotalStudentNum();
    }


    //@Override
   // public List<Long> findStudentsByUserName(String name) {
    //    return studentRepository.findStudentsByUserName(name);
    //}

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long studentId){
        studentRepository.deleteStudent(studentId);
    }

   /* @Override
    public void addGroupById(Long groupId, Long studentId) {
        List<Long> newGroups = findById(studentId).get().getGroups();
        newGroups.add(groupId);
        studentRepository.addGroupById(newGroups,studentId);
    }

    @Override
    public List<Long> getGroupsById(Long id) {
        return studentRepository.getGroupsById(id);
    }

    @Override
    public void addCourseById(Long courseId, Long studentId) {
        List<Long> newGroups = findById(studentId).get().getCourseList();
        newGroups.add(courseId);
        studentRepository.addGroupById(newGroups,studentId);
    }*/
}
