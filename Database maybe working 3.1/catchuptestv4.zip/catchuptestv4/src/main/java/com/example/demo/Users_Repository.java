package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Users_Repository extends JpaRepository<Users,Long> {
}
