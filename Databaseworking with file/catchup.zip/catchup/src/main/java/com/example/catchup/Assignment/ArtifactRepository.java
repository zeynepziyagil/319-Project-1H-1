package com.example.catchup.Assignment;

public interface ArtifactRepository {
}
