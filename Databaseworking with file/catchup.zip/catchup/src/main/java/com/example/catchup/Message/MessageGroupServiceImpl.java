package com.example.catchup.Message;

public class MessageGroupServiceImpl {
}
