package com.example.catchup;

import com.example.catchup.Assignment.Artifact;
import com.example.catchup.Course.*;
import com.example.catchup.Message.ConversationClass;
import com.example.catchup.Message.ConversationClassRepository;
import com.example.catchup.Message.Pair;
import com.example.catchup.Review.ArtifactReview;
import com.example.catchup.Review.ArtifactReviewRepository;
import com.example.catchup.Review.PeerReview;
import com.example.catchup.Review.PeerReviewRepository;
import com.example.catchup.User.Student;
import com.example.catchup.User.User;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;


@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
public class CatchupApplication {

    public static void main(String[] args) {
        SpringApplication.run(CatchupApplication.class, args);
        /*SpringApplication.run(CatchupApplication.class, args);*/
    }

    @Bean
    ApplicationRunner applicationRunner(ConversationClassRepository Repository){
        return args -> {
           //Repository.save(new Pair(null,null));
        };
    }
}