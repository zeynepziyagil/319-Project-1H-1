package com.example.catchup.Message;


import com.example.catchup.User.Student;

import java.util.List;
import java.util.Optional;
public interface PairService {
    List<Pair> findAll();

    Optional<Pair> findById(Long id);

    void save(Pair pair);

    void delete(Long id);

    int getTotalPairNum();
}
