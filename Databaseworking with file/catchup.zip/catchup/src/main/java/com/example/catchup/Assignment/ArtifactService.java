package com.example.catchup.Assignment;

public interface ArtifactService {
}
