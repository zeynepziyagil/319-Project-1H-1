package com.example.catchup.Course;

import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Optional;
public interface PollService {
    List<Poll> findAll();

    Optional<Poll> findById(Long id);

    void save(Poll poll);

    void delete(Long id);

    void updatePoll(String name, Duration duration,int questionNum,List<Long> questions, Long id);

    List<Long> getQuestions(Long id);

    int getTotalPollNum();
}
