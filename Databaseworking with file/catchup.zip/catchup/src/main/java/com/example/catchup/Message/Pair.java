package com.example.catchup.Message;
import com.example.catchup.Course.Course;
import com.example.catchup.User.User;
import com.vladmihalcea.hibernate.type.array.ListArrayType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@PrimaryKeyJoinColumn(name = "conversationClassId")
public class Pair extends ConversationClass {
    //other properties
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "userId1", referencedColumnName = "id")
    private User user1;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "userId2", referencedColumnName = "id")
    private User user2;

    public Pair() {
    }

    public Pair(User user1, User user2) {
        super( "Pair");
        this.user1 = user1;
        this.user2 = user2;
    }



    public User getUser1() {
        return user1;
    }

    public User getUser2() {
        return user2;
    }

    @Override
    public String toString() {
        return "Pair{" +
                ", user1Id=" + user1 +
                ", user2Id=" + user2 +
                '}';
    }
}
