package com.example.catchup.Message;
import com.example.catchup.Group.ProjectGroupServiceImpl;
import com.example.catchup.User.Student;
import com.example.catchup.User.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
public class PairServiceImpl implements PairService{
    //properties
    private PairRepository pairRepository;

    @Autowired
    public void setStudentRepository(PairRepository pairRepository) {
        this.pairRepository = pairRepository;
    }

    @Override
    public List<Pair> findAll(){
        return pairRepository.findAll();
    }

    @Override
    public Optional<Pair> findById(Long id){
        return pairRepository.findById(id);
    }

    @Override
    public void save(Pair pair){
        pairRepository.save(pair);
    }

    @Override
    public int getTotalPairNum() {
        return pairRepository.getTotalPairNum();
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long id){
        pairRepository.deletePair(id);
    }
}
