package com.example.catchup.Message;

import java.util.List;
import java.util.Optional;

public interface ConversationClassService {
    List<ConversationClass> findAll();

    Optional<ConversationClass> findById(Long id);

    void save(ConversationClass conversationClass);

    void delete(Long id);

    void updateConversationClass(String option, Long id);

    int getTotalConversationClassNum();
}
