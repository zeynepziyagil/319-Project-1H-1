package com.example.catchup.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class PollServiceImpl implements PollService{
    //properties
    private PollRepository pollRepository;

    @Autowired
    public void setQuestionRepository(PollRepository pollRepository) {
        this.pollRepository = pollRepository;
    }

    @Override
    public List<Poll> findAll(){
        return pollRepository.findAll();
    }

    @Override
    public Optional<Poll> findById(Long id){
        return pollRepository.findById(id);
    }

    @Override
    public void save(Poll poll){
        pollRepository.save(poll);
    }

    @Override
    public void updatePoll(String name, Duration duration, int questionNum, List<Long> questions, Long id) {
        pollRepository.updatePoll(name,duration,questionNum,questions,id);
    }

    @Override
    public List<Long> getQuestions(Long id) {
        return pollRepository.getQuestions(id);
    }

    @Override
    public int getTotalPollNum() {
        return pollRepository.getTotalPollNum();
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long id){
        pollRepository.deletePoll(id);
    }
}
