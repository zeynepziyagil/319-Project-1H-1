package com.example.catchup.Message;

public class MessageGroup {
}
