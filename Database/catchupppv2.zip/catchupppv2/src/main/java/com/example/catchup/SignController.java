package com.example.catchup;

import com.example.catchup.User.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.*;

@RestController
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@CrossOrigin("*")
public class SignController {

    private final StudentService studentService;
    private final InstructorService instructorService;
    private final TeachingAssistantService teachingService;
    private final UserService userService;
    @Autowired
    public SignController(StudentService studentService, InstructorService instructorService, TeachingAssistantService teachingService,UserService userService) {
        this.studentService = studentService;
        this.instructorService = instructorService;
        this.teachingService = teachingService;
        this.userService =  userService;
    }
    //sign in
   @RequestMapping("/sign-in")
    String signIn(@RequestBody User u) {
        String mail = u.getMail();
        String password = u.getPassword();
        if( checkAccount(mail,password) )
        {
            return ""+userService.getIdByMail(mail);
        }
        return "/sign-in";
    }

    @GetMapping("/sign-up") //KONUŞ
    String signUp( int role) {
        if( role == 0)
            return "/sign-up/Student";
        else
            return "/sign-up/Instructor-TA";
    }

    @PostMapping("/sign-up/Student")
    String signUpStudent( @RequestBody Student s) {
        //check existing mail from userService and confirm password
        if(!userService.checkExistEmail(s.getMail()) ){
            studentService.save(s);
            return "/sign-in";
        }
        return "/sign-up";
    }

    @PostMapping("/sign-up/Instructor-TA")
    String signUpInstructorTA( @RequestBody User u) {
        //check existing mail from userService and confirm password
        if(!userService.checkExistEmail(u.getMail()) ){
            if(u.getRole().equals("instructor")){
                Instructor ins = new Instructor(u.getName(),u.getSurname(),u.getMail(),u.getPassword());
                instructorService.save(ins);
            }
            else if(u.getRole().equals("teaching assistant")){
                TeachingAssistant ta = new TeachingAssistant(u.getName(),u.getSurname(),u.getMail(),u.getPassword());
                teachingService.save(ta);
            }
            return "/sign-in";
        }
        return "/sign-up";
    }

    boolean checkAccount(String mail, String password)
    {
        if(userService.getPasswordByMail(mail).equals(password))
            return true;
        return false;
    }
}
