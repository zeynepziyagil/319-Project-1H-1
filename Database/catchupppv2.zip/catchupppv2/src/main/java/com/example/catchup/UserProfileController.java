package com.example.catchup;

import com.example.catchup.Review.PeerReviewService;
import com.example.catchup.User.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@CrossOrigin("*")
public class UserProfileController {

    private final StudentService studentService;
    private final InstructorService instructorService;
    private final TeachingAssistantService teachingService;
    private final UserService userService;
    private final PeerReviewService peerReviewService;

    @Autowired
    public UserProfileController(StudentService studentService, InstructorService instructorService, TeachingAssistantService teachingService, UserService userService, PeerReviewService peerReviewService) {
        this.studentService = studentService;
        this.instructorService = instructorService;
        this.teachingService = teachingService;
        this.userService = userService;
        this.peerReviewService = peerReviewService;
    }

    @GetMapping("/profile/{id}")
    public User getUser(@PathVariable("id") Long id)
    {
        if(userService.getRoleById(id).equals("student") && studentService.findById(id).isPresent())
        {
            return studentService.findById(id).get();
        }
        else if(userService.getRoleById(id).equals("instructor") && instructorService.findById(id).isPresent())
        {
            return instructorService.findById(id).get();
        }
        else if(userService.getRoleById(id).equals("teaching assistant") && teachingService.findById(id).isPresent())
        {
            return teachingService.findById(id).get();
        }
        return null;
    }

    @GetMapping("/profile/{id}/3")
    public List<String> getStudentReviews(@PathVariable("id") Long id)
    {
        List<String> s2 = new ArrayList<>(0);
        if(userService.getRoleById(id).equals("student"))
        {
            List<List<String>>  s = peerReviewService.getFeedbacks(studentService.findById(id).get());
            for(int i = 0; i < s.size(); i++)
            {
                for(int j = 0 ; j < s.get(i).size(); j++)
                {
                    s2.add(s.get(i).get(j));
                }
            }
        }
        return s2;
    }



    @GetMapping("/profile/{id}/1")
    public double getStudentGrade(@PathVariable("id") Long id) {
        double average = 0;
        if (userService.getRoleById(id).equals("student")) {
            double total = 0;
            List<Double> s = peerReviewService.getGrade(id);
            for (int i = 0; i < s.size(); i++) {
                    total = total + s.get(i);
                }
            if(s.size() != 0)
                average  = total / s.size();
            }
        return average;
    }

    @GetMapping("/profile/{id}/2")
    public TimeTable getInstructorTimetable(@PathVariable("id") Long id)
    {
        if(userService.getRoleById(id).equals("instructor") )
        {
            return instructorService.getTimeTableById(id);
        }
        return null;
    }

}
