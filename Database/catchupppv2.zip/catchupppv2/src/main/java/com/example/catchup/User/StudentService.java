package com.example.catchup.User;

import com.example.catchup.Course.Course;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Review.PeerReview;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface StudentService{
    List<Student> findAll();

    Optional<Student> findById(Long studentId);

    void save(Student student);

    void delete(Long studentId);

    //void updateStudent(String name, String surname, String password, Course course, List<Long> conversations, int currentSemester, ProjectGroup group, String department, double averagePeerGrade, List<PeerReview> reviews, Long studentId);

    //List<Long> findStudentsByUserName(String name);

    int getTotalStudentNum();

    //void addGroupById(Long groupId, Long studentId);

    ProjectGroup getGroupsById(Long id);

//    void addCourseById(Long courseId,Long studentId);
void addReviewById(List<PeerReview> reviews,Long studentId );
    void addGroupById(ProjectGroup group, Long studentId);
}
