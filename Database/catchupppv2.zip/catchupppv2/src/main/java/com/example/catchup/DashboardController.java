package com.example.catchup;

import com.example.catchup.Course.Course;
import com.example.catchup.Course.CourseService;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.InstructorService;
import com.example.catchup.User.StudentService;
import com.example.catchup.User.TeachingAssistantService;
import com.example.catchup.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.Long.parseLong;

@RestController
@RequestMapping()
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@CrossOrigin("*")
public class DashboardController {
    private final StudentService studentService;
    private final InstructorService instructorService;
    private final TeachingAssistantService teachingService;
    private final UserService userService;
    private final CourseService courseService;
    private final ProjectGroupService projectGroupService;

    @Autowired
    public DashboardController(StudentService studentService, InstructorService instructorService, TeachingAssistantService teachingService, UserService userService, CourseService courseService, ProjectGroupService projectGroupService) {
        this.studentService = studentService;
        this.instructorService = instructorService;
        this.teachingService = teachingService;
        this.userService = userService;
        this.courseService = courseService;
        this.projectGroupService = projectGroupService;
    }

    @GetMapping("dashboard/{emailUser}")
    public Course getCoursesDashboard(@PathVariable("emailUser") String mail){ //???? LONG????//Not give any error in java
        Long id = userService.getIdByMail(mail);
        return userService.getCourseById(id);
    }

    @GetMapping("/dashboard/group/{emailUser}")//bak duruma göre
    public ProjectGroup getGroupsDashboard(@PathVariable("emailUser") String mail){
       //check if the id belongs student or not
        Long id = userService.getIdByMail(mail);
        if(userService.getRoleById(id).equals("student"))
        {
            return studentService.getGroupsById(id);
        }
        return null;
    }

}
