package com.example.catchup.File;

import com.example.catchup.File.Doc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Transactional
@Repository
public interface DocRepository extends JpaRepository<Doc,Integer> {
}

