package com.example.catchup.User;

import com.vladmihalcea.hibernate.type.array.EnumArrayType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
@Entity
@TypeDef(
        name = "time_table_array",
        typeClass = EnumArrayType.class
)
public class TimeTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Type(
            type = "time_table_array",
            parameters = @org.hibernate.annotations.Parameter(
                    name = "sql_array_type",
                    value = "text"
            )
    )
    @Column(
            name = "timeTable",
            columnDefinition = "text[][]"
    )
    private String timeTable[][];

    public TimeTable() {
        timeTable = new String[10][7];
        timeTable[0][0] = "Monday";
        timeTable[0][1] = "Tuesday";
        timeTable[0][2] = "Wednesday";
        timeTable[0][3] = "Thursday";
        timeTable[0][4] = "Friday";
        timeTable[0][5] = "Saturday";
        timeTable[0][6] = "Sunday";
    }

    public Long getId() {
        return id;
    }

    public String[][] getTimeTable() {
        return timeTable;
    }
}
