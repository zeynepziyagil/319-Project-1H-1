package com.example.catchup;

import com.example.catchup.Review.PeerReview;
import com.example.catchup.Review.PeerReviewService;
import com.example.catchup.User.StudentService;
import com.example.catchup.User.UserService;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@CrossOrigin("*")
public class PeerReviewController {
    private final PeerReviewService peerReviewService;
    private final UserService userService;
    private final StudentService studentService;


    public PeerReviewController(PeerReviewService peerReviewService, UserService userService, StudentService studentService) {
        this.peerReviewService = peerReviewService;
        this.userService = userService;
        this.studentService = studentService;
    }

    @PostMapping("/sign-up/{mail}")
   void makePeerReview(@RequestBody PeerReview pr,@PathVariable String mail) {
        if(userService.getRoleById(userService.getIdByMail(mail)).equals("student"))
        {
           List<PeerReview> prs = pr.getStudent().getReviews();
           prs.add(pr);
           studentService.addReviewById(prs,pr.getStudent().getStudentId());
           peerReviewService.save(pr);
        }
    }

}

