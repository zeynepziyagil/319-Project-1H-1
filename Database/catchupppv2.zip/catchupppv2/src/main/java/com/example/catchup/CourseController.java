package com.example.catchup;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Assignment.AssignmentService;
import com.example.catchup.Course.*;
import com.example.catchup.Group.Advertisement;
import com.example.catchup.Group.AdvertisementService;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@CrossOrigin("*")
public class CourseController {
    private final StudentService studentService;
    private final InstructorService instructorService;
    private final TeachingAssistantService teachingService;
    private final UserService userService;
    private final CourseService courseService;
    private final AssignmentService assignmentService;
    private final PollService pollService;
    private final ProjectGroupService projectGroupService;
    private final AnnouncementService announcementService;
    private final AdvertisementService advertisementService;

    @Autowired
    public CourseController(StudentService studentService, InstructorService instructorService, TeachingAssistantService teachingService, UserService userService, CourseService courseService,AssignmentService assignmentService, PollService pollService, ProjectGroupService projectGroupService, AnnouncementService announcementService, AdvertisementService advertisementService) {
        this.studentService = studentService;
        this.instructorService = instructorService;
        this.teachingService = teachingService;
        this.userService = userService;
        this.courseService = courseService;
        this.assignmentService = assignmentService;
        this.pollService = pollService;
        this.projectGroupService = projectGroupService;
        this.announcementService = announcementService;
        this.advertisementService = advertisementService;
    }

    @GetMapping("/coursePage/{userMail}")
    public String getCourseName(@PathVariable("userMail") String mail)
    {
        Long id = userService.getIdByMail(mail);
        return userService.getCourseById(id).getName();
    }

    @GetMapping("/coursePage/{stuId}/{courseId}/assignments")
    public List<Assignment> getAssignments(@PathVariable("stuId") Long stuId,@PathVariable("courseId") Long courseId)
    {
        //Assignments
        List<Assignment> ass = new ArrayList<>(0);
        List<Long> ids = assignmentService.getAssignmentId(courseService.findById(courseId).get());
        for(int i = 0; i < ids.size(); i++ )
        {
            ass.add(assignmentService.findById(ids.get(i)).get());
        }
        return ass;
    }
    //Polls
    @GetMapping("/coursePage/{stuId}/{courseId}/poll")
    public List<Poll> getPolls(@PathVariable("stuId") Long stuId,@PathVariable("courseId") Long courseId)
    {
        //Polls
        List<Poll> polls = new ArrayList<>(0);
        List<Long> ids = pollService.getPollId(courseService.findById(courseId).get());
        for(int i = 0; i < ids.size(); i++ )
        {
            polls.add(pollService.findById(ids.get(i)).get());
        }
        return polls;
    }

    //ProjectGroups
    @GetMapping("/coursePage/groups/{userMail}")
    public List<ProjectGroup> getProjectGroups(@PathVariable("userMail") String mail)
    {
        List<ProjectGroup> pg = new ArrayList<>(0);
        Long id = userService.getIdByMail(mail);
        List<Long> ids = projectGroupService.getGroupId(userService.getCourseById(id));
        for(int i = 0; i < ids.size(); i++ )
        {
            pg.add(projectGroupService.findById(ids.get(i)).get());
        }
        return pg;
    }

    //Announcements
    @GetMapping("/coursePage/{stuId}/{courseId}/announcement")
    public List<Announcement> getAnnouncements(@PathVariable("stuId") Long stuId, @PathVariable("courseId") Long courseId)
    {
        List<Announcement> ann = new ArrayList<>(0);
        List<Long> ids = announcementService.getAnnouncementId(courseService.findById(courseId).get());
        for(int i = 0; i < ids.size(); i++ )
        {
            ann.add(announcementService.findById(ids.get(i)).get());
        }
        return ann;
    }

   //Advertisements
    @GetMapping("/coursePage/{stuId}/{courseId}/advertisement")
    public List<Advertisement> getAds(@PathVariable("stuId") Long stuId, @PathVariable("courseId") Long courseId)
    {
        List<Advertisement> ad = new ArrayList<>(0);
        List<Long> ids = advertisementService.getAdvertisementId(courseService.findById(courseId).get());
        for(int i = 0; i < ids.size(); i++ )
        {
            ad.add(advertisementService.findById(ids.get(i)).get());
        }
        return ad;
    }

}
