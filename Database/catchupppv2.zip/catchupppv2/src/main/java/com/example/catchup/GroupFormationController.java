package com.example.catchup;

import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupRepository;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.Student;
import com.example.catchup.User.StudentService;
import com.example.catchup.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@CrossOrigin("*")
public class GroupFormationController {
    private final UserService userService;
    private final StudentService studentService;
    private final ProjectGroupService projectGroupService;

    @Autowired
    public GroupFormationController(UserService userService, StudentService studentService, ProjectGroupRepository projectGroupRepository, ProjectGroupService projectGroupService) {
        this.userService = userService;
        this.studentService = studentService;
        this.projectGroupService = projectGroupService;
    }

    @PostMapping("/form-assis-group/{mail}")
    void formGroupAssistant(@RequestBody ProjectGroup pg, @PathVariable String mail) {
        if(userService.getRoleById(userService.getIdByMail(mail)).equals("teaching assistant"))
        {
            projectGroupService.save(pg);
            //add group to the students
            //get the students of the group
            List<Student> students = pg.getStudents();
            for(int i = 0 ; i < students.size(); i++)
            {
                //add the group to all of the student
                studentService.addGroupById(pg,students.get(i).getStudentId());
            }
        }
    }
}
