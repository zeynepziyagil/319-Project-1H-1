package com.example.catchup.User;

import com.example.catchup.Course.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class UserServiceImpl implements UserService {
    //properties
    private UserRepository userRepository;
    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public List<User> findAll(){
        return userRepository.findAll();
    }

    @Override
    public Optional<User> findById(Long id){
        return userRepository.findById(id);
    }

    @Override
    public void save(User user){
        userRepository.save(user);
    }

    @Override
    public void updateUser(String name, String surname, String password, Course course, List<Long> conversations, Long id) {
        userRepository.updateUser(name,surname,password,course,conversations,id);
    }

    @Override
    public int getTotalUserNum() {
        return userRepository.getTotalUserNum();
    }


    @Override
    public boolean checkExistEmail(String mail) {
        return userRepository.checkExistEmail(mail);
    }

    @Override
    public List<Long> findUsersByUserName(String name) {
        return userRepository.findUsersByUserName(name);
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long id){
        userRepository.deleteUser(id);
    }

    @Override
    public Long getIdByMail(String mail) {
        return userRepository.getIdByMail(mail);
    }

    @Override
    public String getPasswordByMail(String mail) {
        return userRepository.getPasswordByMail(mail);
    }

  //  @Override
   // public List<Long> getCourseListById(Long id) {
       // return userRepository.getCourseListById(id);
    //}

    @Override
    public String getRoleById(Long id) {
        return userRepository.getRoleById(id);
    }

    @Override
    public Course getCourseById(Long id) {
        return userRepository.getCourseById(id);
    }


}
