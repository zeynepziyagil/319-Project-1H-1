import React from "react";
import Logo from "./Logo";
import SignUpForm2 from "./SignUpForm2";

function SignUpPageInstructor() {
    return (
        <div>
            <Logo />
            <SignUpForm2 />
        </div>

    );
}

export default SignUpPageInstructor;