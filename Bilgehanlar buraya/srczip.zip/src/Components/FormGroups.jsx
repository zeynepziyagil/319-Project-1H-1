import React from 'react'
import {Link} from "react-router-dom";
import Boxy from "./Boxy";
import Popup from "reactjs-popup";
import axios from "axios";

  function FormGroups() {
    var x =[];
    var emailUser = sessionStorage.getItem('userMail'); 
    function add(){
      return (
        <div>
          <label>Group Name:</label><br></br>
           <input onChange={handleChange} type="text" id="name"/><br></br>
          <label>Max Group Size:</label><br></br>
           <input onChange={handleChange} type="text" id="maxMemberNum"/><br></br>
           <label>Current Group Size:</label><br></br>
           <input onChange={handleChange} type="text" id="memberNum"/><br></br>
           {}
       </div>);
    }

    function textshow()
    {

        return(
            <div>
            <label>Student ID add to the group:</label><br></br>
           <input onChange={handleChange} type="text" id="studentId1"/><br></br>
           <label>Student ID add to the group:</label><br></br>
           <input onChange={handleChange} type="text" id="studentId2"/><br></br>
           <label>Student ID add to the group:</label><br></br>
           <input onChange={handleChange} type="text" id="studentId3"/><br></br>
       </div>
        )
    }


    const contentStyle = {
        maxWidth: "600px",
        width: "90%"
      };

    const [info,setInfo] = React.useState({name: "", memberNum:"", maxMemberNum: "",  studentId1:"",studentId2:"",studentId3:""});
    function handleChange(event) {
        setInfo({ ...info, [event.target.id]: event.target.value });
    }

    function showMessage(event) {

      axios.post("http://localhost:8080/form-assis-group/" + emailUser,info).then(function(response){
         sessionStorage.setItem('userMail', info.mail);
          const sss = sessionStorage.getItem('userMail');
      });
  };
    return (
        <Popup
        trigger={<button className="form-group-button" type="button">Form Group</button>}
        
        modal
        contentStyle={contentStyle}
      >
        {close => (
          <div className="modal">
            <a className="close" onClick={close}>
              &times;
            </a>
            <div className="content">
              { add()}
              {info.currentSize !== "" ? textshow() : <label></label>}
            </div>
            <center><div className="actions">
            <button className="buttonxs" onClick={showMessage}>Confirm
  </button>
  <button className="buttonxs" onClick={() => { close(); window.location.reload(false)}}><Link to="CoursePageStudent">Close</Link> </button>
  
            </div></center>
          </div>
        )}
      </Popup>
    );
}

export default Boxy(FormGroups);