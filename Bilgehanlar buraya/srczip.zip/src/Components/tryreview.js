import React from "react";

var tryreview = [{
        id: 1,
        message: "Great group member",
        reviewer: "ilke kaş",
        grade: 5,
    },
    {
        id: 1,
        message: "Great group member",
        reviewer: "onat postacı",
        grade: 5,
    },
    {
        id: 1,
        message: "Great group member",
        reviewer: "zeynep ziyagil",
        grade: 5,
    },
    {
        id: 1,
        message: "Great group member",
        reviewer: "yaren yılmaz",
        grade: 5,
    }
];

export default tryreview;