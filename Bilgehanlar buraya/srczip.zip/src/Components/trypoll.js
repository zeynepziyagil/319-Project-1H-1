import React from "react";

var trypoll = [{
        id: 0,
        que: "age?",

    },
    {
        id: 4,
        que: "Rate your Java knowledge from 1 to 4",
        ans: ["1", "2", "3", "4"],

    },
    {
        id: 3,
        que: "Which language do you feel most comfortamble?",
        ans: ["Java", "C++", "Python"],
    },
    {
        id: 0,
        que: "Add something if you want.",

    }
];

export default trypoll;