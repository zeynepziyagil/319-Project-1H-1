import React from "react"
import GiveAdButton from "./GiveAdButton";
import axios from "axios";

function Requests() {
    const emailUser = sessionStorage.getItem('userMail');
    const [Reqs, setReqs] = React.useState([]);
    const str2 = "http://localhost:8080/coursePage/TA/requests/" + emailUser;
    const fetchReqs = () => {
        axios.get(str2).then(response => {
            console.log("buraaa3s");
            console.log(response.data);
            setReqs(response.data);
        })
    };
    React.useEffect(() => {
        fetchReqs();
    }, []);
    function showElement(add)
    {
    return(<div><p>{add.title}:{add.text}</p>
       </div>)

    }
    return (
        <div>
            <div className="reqs">
                <div className="top">
                    <h2>Formation Requests</h2>
                </div>
                <div>
                {Reqs.map(showElement)}
                </div>
            </div>
        </div>
    );
}

export default Requests;