import React from 'react'
import {Link} from "react-router-dom";
import Boxy from "./Boxy";
import Popup from "reactjs-popup";
import axios from "axios";
  
  function GiveAdButton() {
    var emailUser = sessionStorage.getItem('userMail'); 
    function add(){
      return (
        <div>
          <label>AD Title</label><br></br>
           <input onChange={handleChange} type="text" id="title"/><br></br>  
          <label>AD Explanation</label><br></br>
           <input onChange={handleChange} type="text" id="description"/><br></br>            
       </div>);
    }
    
    const contentStyle = {
        maxWidth: "600px",
        width: "90%"
      };
    
    const [info,setInfo] = React.useState({title: "", description: ""});
    function handleChange(event) {
        setInfo({ ...info, [event.target.id]: event.target.value });
    }
    
    function showMessage(event) {
      
      axios.post("http://localhost:8080/make-advertisement/" + emailUser,info).then(function(response){
         sessionStorage.setItem('userMail', info.mail);
          const sss = sessionStorage.getItem('userMail');
      });
  };
    return (
    <Popup
      trigger={<button className="give-ad-button" type="button">Give Advertisement</button>}
      
      modal
      contentStyle={contentStyle}
    >
      {close => (
        <div className="modal">
          <a className="close" onClick={close}>
            &times;
          </a>
          <div className="content">
            { add()}
          </div>
          <center><div className="actions">
          <button className="buttonxs" onClick={showMessage}>share
</button>
<button className="buttonxs" onClick={() => { close(); window.location.reload(false)}}><Link to="CoursePageStudent">Close</Link> </button>

          </div></center>
        </div>
      )}
    </Popup>
    );
}

export default Boxy(GiveAdButton);
