import React from "react";
import GroupPage from "./GroupPage"
import {Link} from "react-router-dom";
import axios from "axios";

function ProjectGroups() {
    const emailUser = sessionStorage.getItem('userMail');    
    const [courseGroup, setCourseGroup] = React.useState([]);
    const str3 = "http://localhost:8080/coursePage/groups/" + emailUser;
    const fetchCourseGroup = () => {
        axios.get(str3).then(response => {
            console.log("buraaa");
            console.log(response.data);
            setCourseGroup(response.data);
        })
    };

    function showElement(group)
    { 

    return(<div>
     <h2><Link to="GroupPage"><p>{group.name}</p></Link></h2>
       </div>)
    }
    
    React.useEffect(() => {
        fetchCourseGroup();
    }, []);
    return (
        <div className="project-group">
            <div className="top">
                <h2>Project Groups</h2>
            </div>
            <div>
            {courseGroup.map(showElement)}    
            </div>
        </div>
    );
}

export default ProjectGroups;