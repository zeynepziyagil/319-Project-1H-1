import React from "react";

var GroupsThatUploadedAssignment = [
    {
        id: 1,
        groupName: "1-H",
        className: "group-links",
        request: true
    },
    {
        id: 2,
        groupName: "1-F",
        className: "group-links",
        request: false
    },
    {
        id: 3,
        groupName: "1-A",
        className: "group-links",
        request: false
    },
    {
        id: 4,
        groupName: "1-C",
        className: "group-links",
        request: true
    },
    {
        id: 5,
        groupName: "1-F",
        className: "group-links",
        request: true
    }
];

export default GroupsThatUploadedAssignment;