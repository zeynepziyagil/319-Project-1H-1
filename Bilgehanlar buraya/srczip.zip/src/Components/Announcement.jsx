import React from "react"
import Addannoun from "./Addannoun";
import axios from "axios";

function Announcement() {
   
    const emailUser = sessionStorage.getItem('userMail');    
    const [courseAnn, setCourseAnn] = React.useState([]);
    const [userRole, setUserRole] = React.useState({});
    const str3 = "http://localhost:8080/coursePage/announcement/" + emailUser;
    const str2 = "http://localhost:8080/dashboard/enroll-role/" + emailUser;
    const fetchCourseAnn = () => {
        axios.get(str3).then(response => {
            console.log("buraaa2");
            console.log(response.data);
            setCourseAnn(response.data);
        })
    };
    const fetchUserRole = () => {
        axios.get(str2).then(response => {
            console.log(response.data);
            setUserRole(response.data);
        })
    };
    React.useEffect(() => {
        fetchCourseAnn();
        fetchUserRole();
    }, []);

    function showElement(ann)
    {
        return(<div>
            <p>{ann.title }:{ann.description}</p>
       </div>)
    }
    

    return (
        <div className="announcement">
            <div className="top">
                <h2>Announcements</h2>
            </div>
            <div>
            {courseAnn.map(showElement)}
            { userRole.str === "instructor" ? <Addannoun/> : <label></label>}
            </div>

        </div>
    );
}

export default Announcement;


