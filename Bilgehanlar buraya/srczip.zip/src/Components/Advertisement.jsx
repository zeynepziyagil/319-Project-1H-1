import React from "react"
import GiveAdButton from "./GiveAdButton";
import axios from "axios";

function Advertisement() {
    const emailUser = sessionStorage.getItem('userMail');    
    const [courseAd, setCourseAd] = React.useState([]);
    const str2 = "http://localhost:8080/coursePage/advertisement/" + emailUser;
    const fetchCourseAd = () => {
        axios.get(str2).then(response => {
            console.log("buraaa3s");
            console.log(response.data);
            setCourseAd(response.data);
        })
    };
    React.useEffect(() => {
        fetchCourseAd();
    }, []);
    function showElement(add)
    {
    return(<div><p>{add.title}:{add.description}</p>
       </div>)
    
    }
    return (
        <div>
            <div className="advertisement">
                <div className="top">
                    <h2>Advertisement</h2>
                </div>
                <div>
                {courseAd.map(showElement)}
                </div>
                <GiveAdButton />
            </div>
        </div>
    );
}

export default Advertisement;