import React from "react";


export default Comp => () => (
    <div className="boxy">
      <Comp />
    </div>
  );
