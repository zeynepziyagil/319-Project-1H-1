import React from "react";

var Messages = [
    {
        id : 1,
        message : "Yes, we can arrange a meeting tomorrow.",
        sender : "You",
    }, 
    {
        id : 1,
        message : "Are you available at 15:30?",
        sender : "Ali Yavuz",
    },
    {
        id : 1,
        message : "If you are, I can come and talk with you.",
        sender : "Ali Yavuz",
    },
    {
        id : 1,
        message : "Yes, it is OK",
        sender : "You",
    }
];

export default Messages;