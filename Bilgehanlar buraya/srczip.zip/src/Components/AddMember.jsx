import React from 'react'
import {Link} from "react-router-dom";
import Boxy from "./Boxy";
import Popup from "reactjs-popup";
import axios from "axios";
import {AiOutlinePlusCircle} from "react-icons/ai";


const contentStyle = {
  maxWidth: "600px",
  width: "90%"
};

  function AddMember(props) {
    var emailUser = sessionStorage.getItem('userMail'); 
    function Add(){
      return (
        <div>
          <label>Enter the id of the students that you want to be grouped with:</label><br></br>
          <input onChange={handleChange} type="text" id="str" value= {info.str}/><br></br>
        </div>)
        ;
    }


    const [info,setInfo] = React.useState({str:""});
    function handleChange(event) {
        setInfo({ ...info, [event.target.id]: event.target.value });
        console.log(info.str);
    }

    function showMessage(event) {

       axios.post("http://localhost:8080/add-member-group/" + emailUser,info).then(function(response){
           sessionStorage.setItem('userMail', info.mail);
            const sss = sessionStorage.getItem('userMail');
        });
    };
    return (
    <Popup
      trigger={<td><AiOutlinePlusCircle size="2em" /></td>}

      modal
      contentStyle={contentStyle}
    >
      {close => (
        <div className="modal">
          <a className="close" onClick={close}>
            &times;
          </a>
          <div className="content">

            {Add()}
          </div>
          <div className="actions">
          <button onClick={showMessage} type="button" className="buttonxs">Add</button>
            <button className="buttonxs" onClick={() => { close();window.location.reload(false)}}><Link to="GroupPage">Close</Link> </button>
          </div>
        </div>
      )}
    </Popup>
    );
  }

export default Boxy(AddMember);