import React from 'react'
import StudentProfile from "./StudentProfile" 
import {Link} from "react-router-dom";
import AddMember from './AddMember';
import RemoveMember from './RemoveMember';
import axios from "axios";


function GroupInfoBox() {
    var emailUser = sessionStorage.getItem('userMail');
    const [userGroup, setUserGroup] = React.useState({});
    const [groupMember, setMembers] = React.useState([]);
    const str1 = "http://localhost:8080/group-formation/group/" + emailUser;
    const str2 = "http://localhost:8080/dashboard/group/" + emailUser;

    const fetchStudents = () => {
        axios.get(str1).then(response => {
            setMembers(response.data);
        })
    };
    const fetchUserGroup = () => {
        axios.get(str2).then(response => {
            setUserGroup(response.data);
        })
    };
    React.useEffect(() => {
        fetchUserGroup();
        fetchStudents();
    }, []);
    function showMembers(member){
        return (
        <div>
            <h3><Link to="StudentProfile">{member.name}</Link></h3>
        </div>
        );
    }
    return (
        <div className="groupinfo">
            <center>
                <h2>{userGroup.name}</h2>
                <table><tr><td> <AddMember/></td><td><RemoveMember/></td></tr></table>
                {groupMember.map(showMembers)}
            </center>
        </div>
    )
}

export default GroupInfoBox;
