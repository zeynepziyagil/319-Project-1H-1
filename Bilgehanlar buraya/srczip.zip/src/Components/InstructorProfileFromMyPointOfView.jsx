import React from "react";
import LogoUpper from "./LogoUpper";
import Menu from "./Menu";
import {FiSend} from "react-icons/fi"
import {TiEdit} from "react-icons/ti"
import {GoLocation} from "react-icons/go";
import axios from "axios";

function InstructorProfileFromMyPointOfView() {
    var emailUser = sessionStorage.getItem('userMail');
    const [userProfile, setUserProfile] = React.useState({});
    const [userCourse, setUserCourse] = React.useState({});
    const str = "http://localhost:8080/profile/instructor/" + emailUser;
    const str2 = "http://localhost:8080/dashboard/" + emailUser;
    const fetchUserProfile = () => {
        axios.get(str).then(response => {
            setUserProfile(response.data);
        })
    };
    const fetchUserCourse = () => {
        axios.get(str2).then(res => {
            console.log(res.data);
            setUserCourse(res.data);
        });
    };
    React.useEffect(() => {
        fetchUserProfile();
        fetchUserCourse();
    }, []);
    var space = "  ";
    return (
        <div>
            <LogoUpper />
            <Menu />
            <table className="profile-table2">
                <tr>
                    <td><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgVFRUYGBgYGhoYGBoYGBgYGBgYGBgaHBoYGBgcIS4lHB4rIRgYJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISHjQrISE0NDQ0NDQ0NDQ0NDQ0NDQ0NDExNDE0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAKoBKQMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAABAgMEAAUHBgj/xABAEAABAwEFBQUEBwgCAwEAAAABAAIRAwQSITFBUWFxgZEFBiKhsRMyUsEHQnKSwtHwFGKCorLS4fFD4jM0cxX/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/xAAkEQEBAAIBBAEFAQEAAAAAAAAAAQIREgMhMVFBBBMUYaEigf/aAAwDAQACEQMRAD8A2zqbMy5xyyGwJblP4XHmAgwE4ASdIRq0zdHErwf8fY1rU2Vxpj6n8yW+wZMbzvH5oPszsNZAOGOeh3pm2R/wlTV9L/n3/Tm0xEMaOQT0KxMz5CNcMkn7E/YrDLKROyNSFuTJm3DXYrq29KLQf16qUWYauGzNTWamxpkw7rAO3JZmOVLnjJ2V21Mf9oOqmVatDGuN6Y1wTssgIjbrGUb1ft5bPuzXdStDjDeZ/XRV4WyfSYYBndkEPZMGnU/4VuKTPXw1wCxxP+FsrjPgCJIYPC0A/KRgU4ftb1f01ZYSJgxMc4mFNaKRLGgDU+oVr2h0DRyTe1dnMRsSYyJlnlddvDUizPP1T5pm2B5+oei2vtXfEeCjdUcdT69FeMTlkis3Z0CX03OOwmAOmJSO7KdeMAAThjkN6t0akubjrpw1WNfhjgrZGZct+QstiuB0ub4hHvaqWjY/CReaRAnWMRiNhwHJIHDLmPzTtf6p2SzL2UWJvxCdMCk/ZGg+8eEKw57QZB4KJ1QTqUsizd+aLKDYJByjT/KIYJyMbZSOfAMjUbsgSoXWtozIHEhOye+/9WyWxF2dcT+tqy+BjcEKkztSmMb7Bxe380ju0qZxvg/ZBPoqzeM83+tg60Ro0brqV1sccsP4clrXW5mheeDKh/CgbXP1Kh/gIn70J39JvCebGzbXJnEkgt3fWCx16TJwG9axtqdLiKb8Q0fUA8Jn41KLQ8/8f3nt+Uq8brwn3enLe8WyNn+lIBO1UW1anws5vd/Yj7Sp+51efkFJhkt+o6ftcH64p8Ny17XVNXM+67+9ENefr9GADzJWphWL9V0/22BfCF/9SqBpu+N3K5/aj4vjf/J/anC+2fy8PVZRtF0mABpIGMTCb9pJy55LWPc/GGtx/f8A+qE1BowfxOP4QnHJv7vS9tv+0nah7ScyVrWuf8TPuuPzCLQ8fXb9z83JwyT73TjZ1c89AknaqD2OJkvdlGAaPUFD2Z1e882j0arwqT6nCTXddcQNd/zTh614s7dS8x++75FMKDd/Nzj804ftL9Vh6rYMfM8CgLSJxIha/wBg34Qj7Fvwt6BXh+2Pypvwr9u96KNmERfeRLWtPmTovLWjvxaXnwMYwY5gvOueSrt7JFVz6r3GXucWgaMnw57leodhsMYlZyyxx7V2kzz7zsis/fqu0xVpscNS2WHLZkvT9md4KddhcwPLsJbdJLcokjCFrh3fpOEluW9ayjZP2W1U3MkMqG45s5EzB6ws45Y5XWjKdTDG3e3rTa36U39GD1coxXefqGQZm8wehKmvItGZ/XBdOOLzflZ/GkLq1X4G83/9UwZVdowH7Tj+FWTSAGLhlgP1okDynHH0zfqOp7IxlVpBvsn7Lj+IIQ/4wBuZ+bipDUSFyWY+mb1up7I4PP8AyO5NYPwoBh+N5/iA/pATgotTszernfmojSG1541H/wByDqDTmCeLnH1KsGmf5rvP8suqje0gwRBU2zc8r5qP9mZ8DTxaD6p2UWDJjRwa0fJFwI5ieqnNmIPT+YSJHCVd1ndIAiSU7KN44EESBOMYyZM7IPRMzFrhoMRxkDzGm5AgREJ6bREnbiZ0wy2ovLCY3HGfrAemEc1RDKdpT0GB3hyJiDu1HTHkspVG3jPu/wCcI/WKILWzO0abQM+aSVJQdjeJyBPHQdSQsogTmAYwnKcM+UoEKIKnqFr3ATMgNvAR4pImNhULyJMZThw0QYUqxGUFK8hBRWStNgAigSslQMiklGUDyjeUcoEpsPKDzgY2H0QlUe26rmUKjmGHBuBGkkAnom1k3dPNWWuGMZfvQWtJhpMYawvRdnupvb4Hg/rVaB/Zz3tYWOddDW4AxOAzwxWw7KsRbVLsBJ9xslrdwk5Ly56r63T5Ttptaltpt8N8lxyDQXegwWn7aaXFjhIiowYiIN5XK/YQdWZVBEtOLTkZ2tyKmtdguMaH+Jt9rocT8Qwk5BZxsmrFyxyyllbW54Z+R9VlMYOHAjlp0J6Kj2c+WaxefE4m7eMDkMOSvtfDTvIHzPyXql3Nvk548crPQNOOO89Anp0i7LPPzA9SosWw7bz5HkfNY15GRIVZSspTJa7BoJnI4CcvJYYkEx7s44AnfG6CgKvhd8ToE7gZPmGqEqIstDdCMjM8Bt1mcBoq95AFG6gepUkNGcTPE6cIDVlarfMkYxB3ka9IURTNaYnRRD1apdE6ADomdXJ3ZHDDECB0UZSgILLasNOPidgdzR8z6TtS3zEaZ81FKaU2hliAWFA7Hx0I6iEFjQsAVGBMHJYQJQTsfBncY4kRKSUl5G8mw15ZeSSsRFS8jeUF5ZexWnRNeWByiBTAoJJRBSAogoGlFKCiEBUdppX2OZ8QITyslRZdXbTUbUaRLHfVGMcNFQZanNe1zHkC85xBjxE5AnPCArXbzLlZujnU2vja10wRtwCo2azAmWsZjtAXC4yW7fT6edyxjf0bS0+L2kuDpEuBOON2Niu2mqajmg6QeYy81SbZWht5zWSNQBh9nYrljulpcc74b/DBJPp0WMcd5anhrrZ3HC35FjA0QEzX4RmPntCmrOxF4Nu4wG3fd5eUqKq0NgSDrO45fnzXp1p8rK23dB7yQAchlluHyHRAIveLrBqAZ+8UC/CPnhzwxRkzWmCdBAPOY9CmLDAOhkDlE+qNASLg1IM6ANDpJ6zyUlRzSCcboIY3bEEzxJg8yghCkp6nYPMkD5nokMXQQMTOs5GEWnwu2Ydf9Sgam4YznoYmNqapWJAGg4STtJVeUzcck2ghM9ogbSJ9Uh3qSrUBiBEAbemKgRzMOUnnl6jqmLIAOhEj0ITF4x3tAyyIu7eCDX3bs44l0biB0OE9EAATsZLru478mk/JBtcxGeMySZ088M95RbXIffA/REHKM8eqIy6cMMzA47PMJmYgpqVS61zo3NnEh0Zg7gT1CiY+AcJVgtWmhdmBk5w5Q0j1VNylfaS6ZAxM8MIw5AKElKUzSsKUIygIKMoI3kRqi5G8lKAVdErUwSgrLyCSUQVECnlUPKaVGFIckAlWLJZH1HXWCdp0A2lTdldlPrGfdYM3fJu0r21ksbKbQxjYHrvO0q447amLTdvd3KVqphjwQW+49mD2ECBdOzccCuedrd3bZY/GWttFIf8AIzwPaP32Y9RguvsMOuuyPun8PFSXIyWssJlHXHO4+HErHanPzkDYV6PsqzPeyrEXaYa+dQT7zeF2Dy3qLvJ292W2s5lOQ9riHvpNJYHg4i7g13FpzBW97nWukKNT2J9s51SargxwY2WNFwXgC4hgZIiJcuGPTymXfw7Z545Ya+WoYASATA1O5Co+STt8ty9da+7lN4vUzcJxGrTyOIWgt/YlakJLbzdrMQOIzC6XGx47jY1qYJViwylZVIBA1ETumT1hKXaaLHNiN4n1jyhKgmNZxEFxI2ElBhkEYYwcSAMJ1PFRp3tAjaQDuxRGThGHT5qwbVgQGjHcMBsBABAUVOiTmQBEyZy9OSR8A5ygJJJk6lEFRlyYOQO1EhJeWSiCilvIoGLzAGgmOeaCVZKBlgKWVgKB5WSo3ORJVRLKEpWlZfQagPT3lUvJr606rIemDlTD04eoi6HLA5VBUTiqgtBy3XYXZXtjffNwH7x2cNpWq7Lsjq7wxuAzcfhbqeK6HZaLWMDGiGtAA4fmt4zbWOPynpMDQA0AAYADADgpQErUxyW2yVqQcIP+jtCZjDEOx0O9MmCDl/f76PrM2nUtVF3sXNF9zImm87hmwndhuWv+h3t1oe+yuwvkvY7a9rQHMI2lrA4fZK6H30sZrWOsxudwnjAJhfP3ZNrNmq067c6b2PwzIaRI5iRzQj6cDAExCWjUa9rXtMtc0OadrXCQehTojR9t9gtqgvZDXjkH7nb968WWGQwiHAlpB0M6+a6etN2j2Ayq8vBLHkEEjEGRExthYyx34ZuO3im1Gy5xEiQACAcIMDdgBimp3rhIYCNDcnOZxjTBW+1uw6lAXpD2T7wEQdLw04rU+0IyJHAlc/HlnwaVLUODTujofTPoq17aVPVMhkfDHQmfP1UZKHnKUbyRrCcgTwCx0jAoLdlYTeIBPhOQ1zSTAdyHUz8lDTqkTGoI9PyQFSJ3oLbKeIaR7wF07yARxGihaCUBW+sTJAAHIQCeCVtrDGxvBkkQCDmBGfNBIWkZgp6YmdwkdR+ags9vL3ODTevTezuiddgjMcE9GvdO0EEEAxIIj/KTS3GzVs8muO2Zgu5CZPkU9GmXFo+IgDy/NZQrGCJ8Ia7+YGBPEjBR067mxEYGRhMHcnZlK+nDQ4azs0cQMM9FC0rDUkAQMMjjOJmEocgcrCcEgcscUQ8rISrIQaCVhckJWBbdTBye8ogiSglvIXkrSgXIOg90bOBQa4DF5JJ2gOLQPLzXo3mMFpO6piz0uH4nLbsdedw9V0x8Oi006bsFIDI4hRvGAOxY1+W9aQQ6I34KVQVcQANvQDP9b1MFBjmgjEYL5s7csXsbTXo6MqVGj7F4lv8AKQvpQlcH+kyxGjb6jtKrW1B/FLSOrT5IR0n6Lu1Pb2FjCZfQcaTvsjFn8pA/hXsFxn6G7fctVWgThVphwGl+mScN917ui7NKLQQOaL3QoXVRx4KoeqwOaWuEhwII2g5rRnsCzA3LhxBh19075xzW5L8EHATviB81LJTTxVp7s1Q+GFrmzgSbpHEfkmo93qpNx91o0M3scsI+e5euB8QO2QeSFd0MdwJ6YhZ4ROMaFvdUgY1zgMPBlwN6RrkqNp7r1hJa5j+d1x+9h5r1zKwcxrjk4T1TnqE4ROMc9/8AxbTpQcebR6lRO7EtsFwoEDE+8ycN0rpBqQCeaWpa2tzMRipwhxjkLW1HZm6PNWm0abG334wQMZMSY04qpb+2GGtULA4svvggeGLxgjchT7QJbIGDsWycY2xsXjvK3u+jhOljjuaX3uduuj4R4UrXKCzWh4ZN732w4DIZEt9E7SuuPh4OvZc7q7WvakiJw2YAeSyVCHJw5acEkrCkLkZlAQiEoKJKIkaU8qFpRvK7HnLye8q4ciCtOqclYSopWAlBK16y8o1ig6d2I67Z6P2GnrJ+a3dmbgtN2PSIpUmnSm3+kLeMXaeHWrLMlA/ATsPyU7VFaR4TCrKCz1BMnNWg8LXMJGat0jggsB65V9NNn8VmqbqjOhDh6ldRJyC5x9Mzx7OzM1vvdyDI+aDn/dC3iz26zVSYAqBrvsvBY6d0PX0cV8r1RIPkvpnsW2itZ6NUGb9Nj+bmifOVFqzbD4DhOXqtYy24wGE6ZwJ4p+89ZzLNUex11zQC0jQhw2rwNDvRaGxIY6DOLYPkpcpE26G0uOLugy/yna2F46n30f8AWpD7/wD1VlnfNhzpOHBzT54Jyico9RqOqjrVG+64jxaHXcF5Wp30EENoQdCXyOYu4rR1u3qriXS0O+INx5Tkpcoco6TTeA2NBtwHVa+19pUabXO9qPDEtYb5xMAQP1gVzivbHv8Afe53Ek+ShLzF3SZ5xCzzZ5PV27vm4yKTA0ZS/En+EYDqV5ztvtKpVN173EQJaDdbJxMtGBiY5KoQjUeJvNkOOJmCJOwRlxWblanKqrW6ACFNTZ03fJWKb2QA5k78MDJxA10wOGCGEkgQNiyzauOaA5xE+ESAQM/CBrjn5IuHgaZEku2zpmf1mq1OsQSc5EEHUHepWPJFwCQTIGZB3Hl5IJ6pkB+2QftCJ6gg8yjcMA7chqcYwCjccA0GYkmMpMZdAmbWyMYtiDOBA0IRDhjsiIwnHDBNRODnbBA4uw9JWMtAEiMIIAnDHOZ3weSyiQQ5s5wRxE4dCUAaU7mRG0iY2CcPQqUOFxxI8QAZxkyOYDSOije8y1wMYNE53S0AHDlKukIshPUcy9IBukYAES3cdsQUvg+J33R/cmh5ZqeFGxyeVp1G8i0pAmBhA4TJAVIAoOt2NsAbgB0CvMK1lkdLWnbirq7OtX2uCS0ZFV9J2LKlcC628ATjB1AVZJ7NPTBapCQsaEDMGq5v9MVI3KLthI6rpbHLw30uMBsjHatqNjgZlBxgruP0VW72lgawmTSe9h4Xr7R0eByXD3rp/wBC1q/9ml9ioP5mO9GqK913pk2WruaOgcFzAvXRe+9e5Znj43NZ1MnyaVzEuXPLy55eU95KHqKUQVhk95YlATBAU8JAmCiDCUtTEoEoEUiRY4oh2p2uULSpGlBM16aVCCnaUEgKZpUcogoLBf4Q0bST5Aenmo5SygiJGuTSogVl5UedBTyogUQVp1SyslRyi0oJgUweoZTtxwQdd7PZDWDQADyWy9iFq2WtrLrTLnEeFrYkxricBitlQLnYkxubpxJ/JdXWpGsI5rX1bKHvLjoA1p8z5rYPaQPC7H96CDuMBRExmM1UVgHs3jar1mqByjL9yDKrR4iQ0DMkwBxJQXboXifpTozYnO+FzT1IW6qd6bM11y+XbXNEtHPXlKTttlG20TZw8ltQE32QSy6c8d+CzMpbqVbjlJux8+yvX/Rfa/Z9oME4VGVKZG8i+3zYOq3Ns+ix2PsrS07A9haerZVfsTuNbrNaqFUtpvayowuLHgwy9DjDgD7pK1pnb1v0juNykPql7ieIbh5Fy8CAukd/7O59BlxjnltQEhrS4xceJgaZLnTqbgYc0jiCPVcsp3Yy8jCyFhWNWbGBTgKMlGVA8rFG5yMoHlAoApXFEFGVHeRlQSLAVHeTByCUFMCopRBQTXkQVEHIgqiUOTXlECmlEOio5QvIPPApg5RBMc1p1SX0Q5QJ0EwcrfZlMPqsYci4TwGJ8gVQCv8AZH/mZxP9JRZ5e+7Lffc+s7Mm6zcN361K2lW0uaWlq1PZHuM5/wBRW0bmumPh1vls22kPAIw2jYURWwjPitU33uQ9VZK0mnku8/e57a5oUXXBTi+4AFznkTcxBhoETtPBaDtLt+rVPjdI0AwaOQ1Wk7U/9u1f/d/9ZUdTJeTLK7r2akk7L1XtFt2MnaOb8xqtpZPpA9l4W2aQAGiH4wOLV5KpkVWYcExvHwmf+vLpNl+klj3Bps9QE7Cx3zC9VZu2Q9ocAYIB012jRcUsuU67deq9B3W98cfwldZnbXLLCadUb2uNqc9pMdg4Bw3gFeYYqvbLyKZgkYaGNFvlXK4zQd7atnL2CkxrXib9wADSAQML2fkvPByjKwLF7156YlM1yjci1RDuWApXrEQxKBKxYoAsQWBA0rAUAiUDSgHILFCnBTtUQTtVEkpgVCnageUJSlBB/9k="/></td>
                    <td className="profile-table-rows">
                    <tr><b>Name:</b> {userProfile.name}</tr>
                    <tr><b>Surname:</b> {userProfile.surname}</tr>
                    <tr><b>Email:</b> {userProfile.mail}</tr>
                    <tr><b>Course: </b>{userCourse.name}</tr>
                    <tr><b>Location of Office:</b> {userProfile.officeLocation}{space}<GoLocation size="1.2em" /></tr>
                    </td>
                </tr>
            </table>
            <div className="edit-profile2"><p>Edit Profile<TiEdit className="edit-icon" size="3em"/></p></div>
        </div>
    );
}

export default InstructorProfileFromMyPointOfView;