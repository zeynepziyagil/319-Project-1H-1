package com.example.catchup.Course;

import com.vladmihalcea.hibernate.type.array.ListArrayType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@TypeDef(
        name = "list-array",
        typeClass = ListArrayType.class
)
public class Poll {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    //properties
    private String name;
    private Duration duration;
    private int questionNum;
    @Type(type = "list-array")
    @Column(
            name = "questions",
            columnDefinition = "bigInt[]"
    )
    private List<Long> questions;

    public Poll() {
    }

    public Poll(String name, Duration duration, int questionNum) {
        this.name = name;
        this.duration = duration;
        this.questionNum = questionNum;
        this.questions = new ArrayList<>(0);
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Duration getDuration() {
        return duration;
    }

    public int getQuestionNum() {
        return questionNum;
    }

    public List<Long> getQuestions() {
        return questions;
    }

    @Override
    public String toString() {
        return "Poll{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", duration=" + duration +
                ", questionNum=" + questionNum +
                ", questions=" + questions +
                '}';
    }
}

