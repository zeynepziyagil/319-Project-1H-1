package com.example.catchup.Course;

public class CourseController {
}
