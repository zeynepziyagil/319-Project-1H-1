package com.example.catchup.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
public interface InstructorRepository extends JpaRepository<Instructor,Long>{
    @Modifying
    @Query("update Instructor i set i.name = :name, i.surname = :surname,i.password = :password, i.courseList = :courseList, i.conversations = :conversations, i.officeLocation = :officeLocation, i.timeTable = :timeTable where i.id = :id")
    void updateInstructor( @Param("name") String name, @Param("surname") String surname ,@Param("password") String password, @Param("courseList") List<Long> courseList, @Param("conversations") List<Long> conversations, @Param("officeLocation") String officeLocation,@Param("timeTable") TimeTable timeTable, @Param("id")  Long id);

    @Query("select count (id) from Instructor")
    int getTotalInstructorNum();

    @Modifying
    @Query("delete from Instructor i  where i.id = :id")
    void deleteInstructor(@Param("id") Long id);

    @Query("select i.id from Instructor i where i.mail =:mail")
    Long getIdByEmail(@Param("mail") String mail);
}
