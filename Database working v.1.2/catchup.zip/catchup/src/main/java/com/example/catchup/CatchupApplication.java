package com.example.catchup;

import com.example.catchup.Assignment.Artifact;
import com.example.catchup.Course.*;
import com.example.catchup.Message.*;
import com.example.catchup.Review.ArtifactReview;
import com.example.catchup.Review.ArtifactReviewRepository;
import com.example.catchup.Review.PeerReview;
import com.example.catchup.Review.PeerReviewRepository;
import com.example.catchup.User.*;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;
@EnableJpaRepositories("com.example.catchup.Course")
@SpringBootApplication
public class CatchupApplication {

    public static void main(String[] args) {
        SpringApplication.run(CatchupApplication.class, args);
    }

    @Bean
    ApplicationRunner applicationRunner(CourseRepository Repository){
        return args -> {
            Repository.save(new Course("CS315"));
        };
    }
}