package com.example.catchup.Message;
import com.example.catchup.Group.ProjectGroupServiceImpl;
import com.example.catchup.User.Student;
import com.example.catchup.User.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
public class MessageGroupServiceImpl implements MessageGroupService{
    //properties
    private MessageGroupRepository messageGroupRepository;

    @Autowired
    public void setMessageGroupRepository(MessageGroupRepository messageGroupRepository) {
        this.messageGroupRepository = messageGroupRepository;
    }

    @Override
    public List<MessageGroup> findAll(){
        return messageGroupRepository.findAll();
    }

    @Override
    public Optional<MessageGroup> findById(Long studentId){
        return messageGroupRepository.findById(studentId);
    }

    @Override
    public void save(MessageGroup messageGroup){
        messageGroupRepository.save(messageGroup);
    }


    @Override
    public int getTotalMessageGroupNum() {
        return messageGroupRepository.getTotalMessageGroupNum();
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long studentId){
        messageGroupRepository.deleteMessageGroup(studentId);
    }

    @Override
    public void updateMessageGroup(int memberNum, String name, List<Long> groupMembers, Long id) {
        messageGroupRepository.updateMessageGroup(memberNum,name,groupMembers,id);
    }
}
