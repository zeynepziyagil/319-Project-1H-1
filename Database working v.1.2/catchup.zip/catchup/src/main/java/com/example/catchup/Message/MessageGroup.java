package com.example.catchup.Message;

import com.vladmihalcea.hibernate.type.array.ListArrayType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@PrimaryKeyJoinColumn(name = "conversationClassId")
@TypeDef(
        name = "list-array",
        typeClass = ListArrayType.class
)
public class MessageGroup extends ConversationClass{
    //other properties
    private int memberNum;
    private String name;

    @Type(type = "list-array")
    @Column(
            name = "groupMembers",
            columnDefinition = "bigInt[]"
    )
    private List<Long> groupMembers;

    public MessageGroup() {
    }

    public MessageGroup( int memberNum, String name, List<Long> groupMembers) {
            super("Message Group");
        if(memberNum > 0) {
            this.memberNum = memberNum;
            this.name = name;
            this.groupMembers = groupMembers;
        }
    }

    public int getMemberNum() {
        return memberNum;
    }

    public String getName() {
        return name;
    }

    public List<Long> getGroupMembers() {
        return groupMembers;
    }

    @Override
    public String toString() {
        return "MessageGroup{" +
                "memberNum=" + memberNum +
                ", name='" + name + '\'' +
                ", groupMembers=" + groupMembers +
                '}';
    }
}
