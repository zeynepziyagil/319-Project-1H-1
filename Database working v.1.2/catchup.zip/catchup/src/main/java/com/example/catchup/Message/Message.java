package com.example.catchup.Message;
import com.example.catchup.User.User;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
public class Message {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    //other properties
    private String text;
    private Date time;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "userId", referencedColumnName = "id")
    private User sender;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "conversationClassId", referencedColumnName = "id")
    private ConversationClass conversationClass;

    public Message() {
    }

    public Message(String text, Date time, User sender, ConversationClass conversationClass) {
        this.text = text;
        this.time = time;
        this.sender = sender;
        this.conversationClass = conversationClass;
    }

    public long getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public Date getTime() {
        return time;
    }

    public User getSender() {
        return sender;
    }

    public ConversationClass getConversationClass() {
        return conversationClass;
    }

    @Override
    public String toString() {
        return "Message{" +
                "id=" + id +
                ", text='" + text + '\'' +
                ", time=" + time +
                ", sender=" + sender +
                ", conversationClass=" + conversationClass +
                '}';
    }
}
