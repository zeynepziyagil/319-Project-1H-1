package com.example.catchup.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
public interface TimeTableRepository extends JpaRepository<TimeTable,Long> {
    @Modifying
    @Query("update TimeTable tt set tt.timeTable = :timeTable where tt.id = :id")
    void updateTimeTable( @Param("timeTable") String timeTable[][], @Param("id")  Long id);


    @Modifying
    @Query("delete from TimeTable tt where tt.id = :id")
    void deleteTimeTable(@Param("id") Long id);
}
