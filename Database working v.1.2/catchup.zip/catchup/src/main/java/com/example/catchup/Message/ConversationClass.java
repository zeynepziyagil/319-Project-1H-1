package com.example.catchup.Message;
import com.example.catchup.Course.Course;
import com.vladmihalcea.hibernate.type.array.ListArrayType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@Entity
@Inheritance (strategy = InheritanceType.JOINED)
public abstract class ConversationClass {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    //other properties
    private String option;

    public ConversationClass() {
    }

    public ConversationClass(String option) {
        this.option = option;
    }

    public long getId() {
        return id;
    }

    public String getOption() {
        return option;
    }

    @Override
    public String toString() {
        return "ConversationClass{" +
                "id=" + id +
                ", option='" + option + '\'' +
                '}';
    }
}
