package com.example.catchup.Review;

import com.example.catchup.User.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import java.util.List;
import java.util.Optional;

public class PeerReviewServiceImpl implements PeerReviewService{

    private PeerReviewRepository peerReviewRepository;
    @Autowired
    public void setAssignmentRepository(PeerReviewRepository peerReviewRepository) {
        this.peerReviewRepository = peerReviewRepository;
    }

    @Override
    public List<PeerReview> findAll() {
        return peerReviewRepository.findAll();
    }

    @Override
    public Optional<PeerReview> findById(Long id) {
        return peerReviewRepository.findById(id);
    }

    @Override
    public void save(PeerReview peerReview) {
        peerReviewRepository.save(peerReview);
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long id){
        peerReviewRepository.deletePReview(id);
    }

    @Override
    public void updatePeerReview(String name, List<String> feedback, double grade, int questionNum, Student rater, Student reciever) {
        peerReviewRepository.updatePReview(name,feedback,grade,questionNum,rater,reciever);
    }

    @Override
    public int getTotalPeerReviewNum() {
        return peerReviewRepository.getTotalPReviewNum();
    }

    @Override
    public List<String> getQuestions(Long id) {
        return peerReviewRepository.getQuestions(id);
    }

    @Override
    public List<String> getFeedback(Long id) {
        return peerReviewRepository.getFeedback(id);
    }
}