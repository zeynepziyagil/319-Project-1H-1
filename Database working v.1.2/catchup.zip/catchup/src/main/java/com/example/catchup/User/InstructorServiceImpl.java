package com.example.catchup.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import java.util.List;
import java.util.Optional;
public class InstructorServiceImpl implements InstructorService {
    //properties
    private InstructorRepository instructorRepository;

    @Autowired
    public void setInstructorRepository(InstructorRepository  instructorRepository) {
        this. instructorRepository =  instructorRepository;
    }

    @Override
    public List<Instructor> findAll(){
        return instructorRepository.findAll();
    }

    @Override
    public Optional<Instructor> findById(Long id){
        return instructorRepository.findById(id);
    }

    @Override
    public void save(Instructor instructor){
        instructorRepository.save(instructor);
    }

    @Override
    public int getTotalInstructorNum() {
        return instructorRepository.getTotalInstructorNum();
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void deleteInstructor(Long id){
        instructorRepository.deleteInstructor(id);
    }

    @Override
    public void updateInstructor(String name, String surname, String password, List<Long> courseList, List<Long> conversations, String officeLocation, TimeTable timeTable, Long id) {
        instructorRepository.updateInstructor(name,surname,password,courseList,conversations,officeLocation,timeTable,id);
    }

    @Override
    public Long getIdByEmail(String mail) {
        return instructorRepository.getIdByEmail(mail);
    }
}
