package com.example.catchup.Message;
import com.example.catchup.User.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
public interface MessageGroupRepository extends JpaRepository<MessageGroup,Long>{
    @Modifying
    @Query("update MessageGroup mg set mg.memberNum = :memberNum, mg.name = :name, mg.groupMembers = :groupMembers where mg.id = :id")
    void updateMessageGroup(int memberNum, String name, List<Long> groupMembers, Long id);

    @Query("select count (id) from MessageGroup")
    int getTotalMessageGroupNum();

    @Modifying
    @Query("delete from  MessageGroup mg where mg.id = :id")
    void deleteMessageGroup(@Param("id") Long id);
}
