package com.example.catchup.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import java.util.List;
import java.util.Optional;
public class MessageServiceImpl implements MessageService{
    private MessageRepository messageRepository;
    @Autowired
    public void setMessageRepository(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    @Override
    public List<Message> findAll(){
        return messageRepository.findAll();
    }

    @Override
    public Optional<Message> findById(Long id){
        return messageRepository.findById(id);
    }

    @Override
    public void save(Message message){
        messageRepository.save(message);
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long id){
        messageRepository.deleteMessage(id);
    }

}
