package com.example.catchup.Message;
import com.example.catchup.Assignment.Assignment;

import java.util.List;
import java.util.Optional;
public interface MessageService {
    List<Message> findAll();

    Optional<Message> findById(Long id);

    void save(Message message);

    void delete(Long id);
}
