package com.example.catchup.Message;
import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Course.Course;
import com.example.catchup.User.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
@Transactional
public interface MessageRepository extends JpaRepository<Message,Long>  {

    @Modifying
    @Query("delete from Message m where m.id = :id")
    void deleteMessage(@Param("id") Long id);

}
