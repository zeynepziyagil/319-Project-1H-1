package com.example.catchup.Message;
import com.example.catchup.User.Student;

import java.util.List;
import java.util.Optional;
public interface MessageGroupService {
    List<MessageGroup> findAll();

    Optional<MessageGroup> findById(Long id);

    void save(MessageGroup messageGroup);

    void delete(Long id);

    void updateMessageGroup(int memberNum, String name, List<Long> groupMembers, Long id);

    int getTotalMessageGroupNum();
}