package com.example.catchup.Course;
import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Course.Course;
import com.example.catchup.Group.Advertisement;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.User.User;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


public interface CourseService {
    List<Course> findAll();

    Optional<Course> findById(Long code);

    void save(Course course);

    void delete(Long code);

    void updateCourse(String name, List<Announcement> announcements, List<Advertisement> ads, List<Assignment> assignments, List<Poll> polls, List<ProjectGroup> groups, Long code);

    List<Announcement> getAnnouncements();

    List<Assignment> getAssignments();

    List<Advertisement> getAdvertisements();

    List<Poll> getPolls();

    List<ProjectGroup> getGroups();

    int getTotalCourseNum();

    String getNameById(Long id);

    void updateUsers( List<User> users, Long code);

    Long getCodeByName(String name);

    void updateAds(List<Advertisement> ads, Long code);

}
