package com.example.catchup;

import com.example.catchup.Assignment.Assignment;
import com.example.catchup.Assignment.AssignmentService;
import com.example.catchup.Course.Course;
import com.example.catchup.Group.ProjectGroup;
import com.example.catchup.Group.ProjectGroupRepository;
import com.example.catchup.Group.ProjectGroupService;
import com.example.catchup.User.Student;
import com.example.catchup.User.StudentService;
import com.example.catchup.User.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class GroupFormationController {
    private final UserService userService;
    private final StudentService studentService;
    private final ProjectGroupService projectGroupService;
    private final AssignmentService assignmentService;

    @Autowired
    public GroupFormationController(UserService userService, StudentService studentService, ProjectGroupRepository projectGroupRepository, ProjectGroupService projectGroupService, AssignmentService assignmentService) {
        this.userService = userService;
        this.studentService = studentService;
        this.projectGroupService = projectGroupService;
        this.assignmentService = assignmentService;
    }

    @GetMapping("/info-group/{mail}")
    public ProjectGroup getGroupInfo(@PathVariable String mail)
    {
        Student s = studentService.findById(userService.getIdByMail(mail)).get();
        return s.getGroups();
    }


    @PostMapping("/form-assis-group/{mail}")
    void formGroupAssistant(@RequestBody ProjectGroup pg, @PathVariable String mail) {
        if(userService.getRoleById(userService.getIdByMail(mail)).equals("teaching assistant"))
        {
            projectGroupService.save(pg);
            //add group to the students
            //get the students of the group
            List<Student> students = pg.getStudents();
            for(int i = 0 ; i < students.size(); i++)
            {
                //add the group to all of the student
                studentService.addGroupById(pg,students.get(i).getStudentId());
            }
        }
    }

    @PostMapping("/add-member-group/{mail}")
    void addMemberToGroup(@RequestBody Student addedStudent, @PathVariable String mail)
    {
        //find the admin
        Student admin = studentService.findById(userService.getIdByMail(mail)).get();
        //find the group of the admin
        ProjectGroup pg = admin.getGroups();
        //find the added student
        Long addedId = addedStudent.getId();
        Student addedStu = studentService.findById(addedId).get();
        if(userService.getRoleById(userService.getIdByMail(mail)).equals("student") && pg.getMemberNum() < pg.getMaxMemberNum())
        {
            //update addedstudent group from table
            studentService.updateGroup(addedId,pg);
            //update group membernum, students, etc.
            List<Student> studentsofpg = pg.getStudents();
            studentsofpg.add(addedStu);
            pg.setStudents(studentsofpg);
            projectGroupService.updateProjectGroupStudent(pg.getStudents(), pg.getMemberNum() + 1, pg.getId());
        }
    }

     @PostMapping("/remove-member-group/{mail}")
     void removeMemberFromGroup(@RequestBody Student removedStudent, @PathVariable String mail)
     {
         //find the admin
         Student admin = studentService.findById(userService.getIdByMail(mail)).get();
         //find the group of the admin
         ProjectGroup pg = admin.getGroups();
         //find the removed student
         Long removedId = removedStudent.getId();
         Student removedStu = studentService.findById(removedId).get();
         if(userService.getRoleById(userService.getIdByMail(mail)).equals("student") && pg.getMemberNum() - 1 > 0)
         {
             //update removedstudent group from table
             studentService.updateGroup(removedId,null);
             //update group membernum, students, etc.
             List<Student> studentsofpg = pg.getStudents();
             studentsofpg.remove(removedStu);
             pg.setStudents(studentsofpg);
             projectGroupService.updateProjectGroupStudent(pg.getStudents(), pg.getMemberNum() - 1, pg.getId());
         }
         else if (userService.getRoleById(userService.getIdByMail(mail)).equals("student") && pg.getMemberNum() - 1 <= 0)
         {
             projectGroupService.delete(pg.getId());
         }
     }

     @PostMapping("/make-deadline-requests/{mail}")
    void makeDeadlineRequest(@RequestBody String assignmentName, @PathVariable String mail) //you will only give the name of the assignment in assignment object
     {
         if(userService.getRoleById(userService.getIdByMail(mail)).equals("student")){
             //get assignment by using its name from its course
            //get student
            Student student = studentService.findById(userService.getIdByMail(mail)).get();
            //get course of this student
            Course course = student.getCourses();
            //get assignment
            List<Assignment> assignments = course.getAssignments();
            Assignment wantedassign = new Assignment();
            //find the assignment with given name
            for(int i = 0 ; i < assignments.size(); i++)
            {
                if(assignments.get(i).getName().equals(assignmentName))
                     wantedassign = assignments.get(i);
            }
            assignmentService.updateRequests(wantedassign.getRequests()+1, wantedassign.getId());
         }
     }

}
