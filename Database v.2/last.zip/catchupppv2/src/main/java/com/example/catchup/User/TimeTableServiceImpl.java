package com.example.catchup.User;

import com.example.catchup.Group.ProjectGroupServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
public class TimeTableServiceImpl  implements TimeTableService{
    //properties
    private TimeTableRepository timeTableRepository;

    @Autowired
    public void setTimeTableRepository(TimeTableRepository timeTableRepository) {
        this.timeTableRepository = timeTableRepository;
    }

    @Override
    public List<TimeTable> findAll(){
        return timeTableRepository.findAll();
    }

    @Override
    public Optional<TimeTable> findById(Long studentId){
        return timeTableRepository.findById(studentId);
    }

    @Override
    public void save(TimeTable timeTable){
        timeTableRepository.save(timeTable);
    }

    @Override
    @Secured(value = "ROLE_ADMIN")
    public void delete(Long id){
        timeTableRepository.deleteTimeTable(id);
    }

    @Override
    public void updateTimeTable(String[][] timeTable,Long id) {
        timeTableRepository.updateTimeTable(timeTable,id);
    }
}
